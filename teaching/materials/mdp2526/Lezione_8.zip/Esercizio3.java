// Esercizio 3: Infiltrazione nella Rete Cyberpunk 
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

// 1. Classe ServerRete 
class ServerRete {
    private String indirizzoIP;
    private boolean contieneFirewall;
    private List<ServerRete> connessioni; // Collezione delle connessioni 

    public ServerRete(String indirizzoIP, boolean contieneFirewall) {
        this.indirizzoIP = indirizzoIP;
        this.contieneFirewall = contieneFirewall;
        this.connessioni = new ArrayList<>();
    }

    public void aggiungiConnessione(ServerRete server) {
        this.connessioni.add(server);
    }

    public String getIndirizzoIP() { return indirizzoIP; }
    public boolean isContieneFirewall() { return contieneFirewall; }
    public List<ServerRete> getConnessioni() { return connessioni; }
}

// 3. Classe Netrunner 
class Netrunner {

    // Metodo esposto richiesto dall'esercizio 
    public boolean propagaMalware(ServerRete nodoIniziale, ServerRete nodoTarget) {
        // Set opportuno per evitare cicli infiniti e tracciare nodi visitati 
        Set<ServerRete> visitati = new HashSet<>();
        // Lista per simulare le tracce lasciate nella rete (filo di Arianna) 
        List<String> percorso = new ArrayList<>();

        boolean successo = esploraRete(nodoIniziale, nodoTarget, visitati, percorso);

        if (successo) {
            System.out.println("Malware propagato con successo!");
            System.out.println("Traccia IP (Filo di Arianna): " + String.join(" -> ", percorso));
        } else {
            System.out.println("Impossibile raggiungere il target " + nodoTarget.getIndirizzoIP());
        }

        return successo;
    }

    // 4. Implementazione ricerca tramite strategia ricorsiva con backtracking 
    private boolean esploraRete(ServerRete corrente, ServerRete target, 
                                Set<ServerRete> visitati, List<String> percorso) {
        
        // Il malware si propaga solo se non c'è firewall attivo 
        if (corrente.isContieneFirewall()) {
            return false;
        }

        // Prima della chiamata ricorsiva, inserite il nodo in HashSet di nodi visitati 
        visitati.add(corrente);
        percorso.add(corrente.getIndirizzoIP());

        // Base case: raggiunto l'obiettivo
        if (corrente.equals(target)) {
            return true;
        }

        // Ricorsione sui nodi adiacenti
        for (ServerRete vicino : corrente.getConnessioni()) {
            // Se il nodo è già presente, interrompete quel ramo 
            if (!visitati.contains(vicino)) {
                if (esploraRete(vicino, target, visitati, percorso)) {
                    return true;
                }
            }
        }

        // Backtracking: se nessun ramo figlio porta alla soluzione, rimuovo il nodo dal percorso logico
        percorso.remove(percorso.size() - 1);
        return false;
    }
}

public class Esercizio3 {
    public static void main(String[] args) {
        System.out.println("--- Test Esercizio 3: Rete Cyberpunk ---");

        ServerRete s1 = new ServerRete("192.168.1.1", false);
        ServerRete s2 = new ServerRete("192.168.1.2", false);
        ServerRete s3 = new ServerRete("192.168.1.3", true); // Ha il firewall
        ServerRete s4 = new ServerRete("192.168.1.4", false);
        ServerRete target = new ServerRete("10.0.0.99", false);

        // Setup grafo con cicli
        s1.aggiungiConnessione(s2);
        s1.aggiungiConnessione(s3);
        
        s2.aggiungiConnessione(s1); // Ciclo intenzionale
        s2.aggiungiConnessione(s4);
        
        s3.aggiungiConnessione(target); // Percorso bloccato dal firewall
        
        s4.aggiungiConnessione(s1); // Ciclo intenzionale
        s4.aggiungiConnessione(target); // Percorso libero

        Netrunner netrunner = new Netrunner();
        netrunner.propagaMalware(s1, target);
    }
}

/* 💡 RIFLESSIONI DEL TUTOR
 * - Decision Making: Si è scelto di utilizzare l'algoritmo di Depth First Search (DFS) implementato
 *                    ricorsivamente. Per gestire il "Filo di Arianna", la lista `percorso` viene modificata ad ogni
 *                    passo e, in caso di fallimento del ramo (Backtracking puro), l'ultimo elemento viene rimosso
 *                    prima di risalire lo stack di chiamate.
 * 
 * - Alternative: Esplorare in ampiezza (BFS tramite una Queue) garantirebbe l'individuazione del
 *                percorso minimo. Tuttavia, il vincolo "ricorsione con backtracking" richiesto dall'esercizio
 *                rende la DFS obbligatoria.
 * 
 * - Pitfalls: Dimenticarsi di fare `percorso.remove(...)` durante il backtracking sporcherebbe la 
 *             stampa finale con nodi ciechi che non hanno portato effettivamente al target. Un altro errore 
 *             classico è non controllare cicli infiniti: il `Set` previene StackOverflowError in grafi ciclici.
 * 
 * - Focus: L'attraversamento di strutture di dati collegate (Grafi generici vs Alberi). L'assenza
 *          di gerarchia rigorosa (due nodi connessi vicendevolmente) introduce la necessità di mantenere
 *          la memoria degli stati (nodi visitati) a runtime.
 */