// Esercizio 2: Bacheca delle Missioni della Gilda 
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Predicate;

// 1. Modello della classe Missione 
class Missione {
    private String titolo;
    private int difficolta; // Livello da 1 a 10 
    private int ricompensaOro;

    public Missione(String titolo, int difficolta, int ricompensaOro) {
        this.titolo = titolo;
        this.difficolta = difficolta;
        this.ricompensaOro = ricompensaOro;
    }

    public String getTitolo() { return titolo; }
    public int getDifficolta() { return difficolta; }
    public int getRicompensaOro() { return ricompensaOro; }

    @Override
    public String toString() {
        return "'" + titolo + "' (Difficoltà: " + difficolta + ", Oro: " + ricompensaOro + ")";
    }
}

// 2. Design Pattern Observer: interfaccia Avventuriero 
interface Avventuriero {
    void riceviNotifica(Missione m);
}

// Implementazione concreta di un Avventuriero
class AvventurieroImpl implements Avventuriero {
    private String nome;

    public AvventurieroImpl(String nome) {
        this.nome = nome;
    }

    @Override
    public void riceviNotifica(Missione m) {
        System.out.println("Il sistema avvisa " + nome + ": Nuova missione disponibile -> " + m);
    }
}

// Classe wrapper per associare l'avventuriero al suo filtro specifico
class Sottoscrizione {
    Avventuriero avventuriero;
    Predicate<Missione> filtro;

    public Sottoscrizione(Avventuriero avventuriero, Predicate<Missione> filtro) {
        this.avventuriero = avventuriero;
        this.filtro = filtro;
    }
}

// 2. Classe BachecaGilda 
class BachecaGilda {
    // L'utilizzo di CopyOnWriteArrayList previene la ConcurrentModificationException
    // se un avventuriero si disiscrive durante un ciclo di notifica 
    private List<Sottoscrizione> iscritti = new CopyOnWriteArrayList<>();

    // 4. Metodo avanzato di sottoscrizione con Predicate 
    public void iscrivi(Avventuriero a, Predicate<Missione> filtro) {
        iscritti.add(new Sottoscrizione(a, filtro));
    }

    public void disiscrivi(Avventuriero a) {
        iscritti.removeIf(s -> s.avventuriero.equals(a));
    }

    // 3. Notifica a tutti gli iscritti 
    public void pubblicaMissione(Missione m) {
        System.out.println("\n[BACHECA] Pubblicata nuova missione: " + m);
        for (Sottoscrizione s : iscritti) {
            // Notifica solo ed esclusivamente se la missione soddisfa il Predicate 
            if (s.filtro.test(m)) {
                s.avventuriero.riceviNotifica(m);
            }
        }
    }
}

public class Esercizio2 {
    public static void main(String[] args) {
        System.out.println("--- Test Esercizio 2: Bacheca Gilda ---");

        BachecaGilda bacheca = new BachecaGilda();

        Avventuriero guerriero = new AvventurieroImpl("Guerriero Thorald");
        Avventuriero ladro = new AvventurieroImpl("Ladro Garret");

        // 5. Test: Il guerriero accetta solo missioni con difficoltà > 7 
        bacheca.iscrivi(guerriero, m -> m.getDifficolta() > 7);

        // 5. Test: Il ladro accetta solo missioni con ricompensa > 500 
        bacheca.iscrivi(ladro, m -> m.getRicompensaOro() > 500);

        // Creazione missioni
        Missione m1 = new Missione("Recupero gattino", 2, 50);
        Missione m2 = new Missione("Sconfiggi il Drago", 9, 10000);
        Missione m3 = new Missione("Furto ai nobili", 5, 800);

        // Esecuzione notifiche
        bacheca.pubblicaMissione(m1); // Nessuno interessato
        bacheca.pubblicaMissione(m2); // Interessa sia Guerriero (diff > 7) che Ladro (oro > 500)
        bacheca.pubblicaMissione(m3); // Interessa solo Ladro (oro > 500)
    }
}

/* 💡 RIFLESSIONI DEL TUTOR
 * - Decision Making: Per memorizzare l'Observer e il suo filtro (Predicate) in un'unica 
 *                    struttura logica, ho creato una classe helper interna `Sottoscrizione`. L'utilizzo di
 *                    `CopyOnWriteArrayList` è la soluzione più sicura per i pattern di pubblicazione-sottoscrizione 
 *                    multithreading/concorrenti, rispettando esplicitamente il vincolo sulle eccezioni.
 * 
 * - Alternative: Si poteva usare una `ConcurrentHashMap<Avventuriero, Predicate<Missione>>`. 
 *                Tuttavia, una lista di wrapper preserva l'ordine temporale di iscrizione, che spesso 
 *                è desiderabile in un pattern Observer.
 * 
 * - Pitfalls: Attenzione al problema sollevato dalla ConcurrentModificationException. 
 *             Usando un normale `ArrayList`, se dentro `riceviNotifica()` un observer invocasse 
 *             `bacheca.disiscrivi(this)`, l'iteratore lanciarebbe l'eccezione, mandando in crash il thread.
 * 
 * - Focus: L'interfaccia funzionale `Predicate<T>` (con il suo unico metodo astratto `.test(T)`) 
 *          ci permette di iniettare codice a runtime disaccoppiando totalmente la logica di filtro
 *          dalla classe BachecaGilda.
 */