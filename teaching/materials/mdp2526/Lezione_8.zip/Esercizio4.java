// Esercizio 4: Simulatore di Arena Fantasy 

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Random;

// 2. Design Pattern Strategy: Interfaccia StrategiaAttacco 
interface StrategiaAttacco {
    int eseguiColpo(Combattente attaccante, Combattente difensore);
}

// 3. Implementazione delle tre strategie distinte 
class AttaccoFurtivo implements StrategiaAttacco {
    @Override
    public int eseguiColpo(Combattente attaccante, Combattente difensore) {
        int danno = 15; // Danno fisso base
        // Raddoppia se i punti vita del difensore sono al massimo 
        if (difensore.getPuntiVita() == difensore.getMaxPuntiVita()) {
            danno *= 2;
        }
        return danno;
    }
}

class MagiaArcana implements StrategiaAttacco {
    @Override
    public int eseguiColpo(Combattente attaccante, Combattente difensore) {
        // Danno proporzionale al numero di lettere del nome 
        return attaccante.getNome().length() * 2;
    }
}

class FuriaGuerriera implements StrategiaAttacco {
    @Override
    public int eseguiColpo(Combattente attaccante, Combattente difensore) {
        // Infligge più danni quanti meno punti vita residui ha l'attaccante 
        int vitaPersa = attaccante.getMaxPuntiVita() - attaccante.getPuntiVita();
        return 10 + vitaPersa;
    }
}

// 1. Classe Combattente 
class Combattente {
    private String nome;
    private int puntiVita;
    private int maxPuntiVita; // Utile per il calcolo delle abilità
    private StrategiaAttacco strategia; // Strategia corrente 

    public Combattente(String nome, int puntiVita, StrategiaAttacco strategia) {
        this.nome = nome;
        this.puntiVita = puntiVita;
        this.maxPuntiVita = puntiVita;
        this.strategia = strategia;
    }

    public String getNome() { return nome; }
    public int getPuntiVita() { return puntiVita; }
    public int getMaxPuntiVita() { return maxPuntiVita; }
    public StrategiaAttacco getStrategia() { return strategia; }

    public void setStrategia(StrategiaAttacco strategia) {
        this.strategia = strategia;
    }

    public void riceviDanno(int danno) {
        this.puntiVita -= danno;
        if(this.puntiVita < 0) this.puntiVita = 0;
    }

    @Override
    public String toString() {
        return nome + " (HP: " + puntiVita + ")";
    }
}

// 4. Modello della classe Arena 
class Arena {
    // PriorityQueue per mantenere ordinati i combattenti in base ai PV crescenti 
    private PriorityQueue<Combattente> codaCombattenti;
    private Random random = new Random();

    public Arena(List<Combattente> combattenti) {
        // L'inizializzazione della coda usa un Comparator personalizzato: chi ha meno vita ha priorità 
        codaCombattenti = new PriorityQueue<>(Comparator.comparingInt(Combattente::getPuntiVita));
        codaCombattenti.addAll(combattenti);
    }

    // 5. Metodo avviaTurno() 
    public void avviaTurno() {
        if (codaCombattenti.size() < 2) {
            System.out.println("Combattenti insufficienti in arena.");
            return;
        }

        // Il primo combattente della coda attacca 
        Combattente attaccante = codaCombattenti.poll();
        
        // Estrazione casuale di un avversario 
        List<Combattente> potenzialiBersagli = new ArrayList<>(codaCombattenti);
        Combattente difensore = potenzialiBersagli.get(random.nextInt(potenzialiBersagli.size()));
        
        // Rimuoviamo temporaneamente il difensore dalla coda: i suoi HP cambieranno!
        codaCombattenti.remove(difensore);

        int danno = attaccante.getStrategia().eseguiColpo(attaccante, difensore);
        difensore.riceviDanno(danno);
        System.out.println(attaccante.getNome() + " attacca " + difensore.getNome() + " infliggendo " + danno + " danni!");

        // Muta dinamicamente la propria strategia se i HP scendono sotto il 30 
        if (attaccante.getPuntiVita() < 30 && !(attaccante.getStrategia() instanceof FuriaGuerriera)) {
            System.out.println(attaccante.getNome() + " cambia strategia: entra in Furia Guerriera!");
            attaccante.setStrategia(new FuriaGuerriera());
        }

        // Re-inseriamo i combattenti in coda (questo forza il riordinamento basato sui nuovi HP)
        if (attaccante.getPuntiVita() > 0) codaCombattenti.offer(attaccante);
        if (difensore.getPuntiVita() > 0) codaCombattenti.offer(difensore);
        
        stampaStatoArena();
    }

    public void stampaStatoArena() {
        System.out.println("Stato Coda (Priorità): " + codaCombattenti);
    }
}

public class Esercizio4 {
    public static void main(String[] args) {
        System.out.println("--- Test Esercizio 4: Simulatore Arena ---");

        Combattente c1 = new Combattente("Elfo Oscuro", 40, new AttaccoFurtivo());
        Combattente c2 = new Combattente("Mago Supremo", 50, new MagiaArcana());
        Combattente c3 = new Combattente("Barbaro", 25, new FuriaGuerriera()); // Partirà per primo per gli HP bassi

        Arena arena = new Arena(List.of(c1, c2, c3));
        arena.stampaStatoArena();
        
        System.out.println("\n--- Turno 1 ---");
        arena.avviaTurno();
        
        System.out.println("\n--- Turno 2 ---");
        arena.avviaTurno();
    }
}

/* 💡 RIFLESSIONI DEL TUTOR
 * - Decision Making: Per supportare appieno il Design Pattern Strategy, la proprietà `strategia` 
 *                    deve poter variare a runtime (es. setter invocato quando gli HP scendono sotto 30). Questo
 *                    disaccoppia il calcolo algoritmico del danno dall'oggetto Combattente.
 * 
 * - Alternative: Per l'estrazione casuale del difensore, si è riversata temporaneamente la PriorityQueue 
 *                in una List. Un approccio alternativo, utile in sistemi con moltissimi nodi, sarebbe un 
 *                iteratore che scorre randomicamente la coda, bypassando la conversione, ma la conversione O(N) 
 *                qui è sicura e leggibile per arene logiche (poche entità).
 * 
 * - Pitfalls: Se si muta lo stato interno di un oggetto (come `puntiVita`) mentre 
 *             questo si trova all'interno di una `PriorityQueue`, l'heap binario sottostante si corrompe e 
 *             perde l'ordinamento. È OBBLIGATORIO fare `remove()` prima della mutazione e `offer()` dopo.
 * 
 * - Focus: Comprendere la gestione della `PriorityQueue`. L'inserimento tramite `Comparator.comparingInt` 
 *          automatizza lo shift-up e shift-down dell'heap per mantenere il combattente più debole costantemente 
 *          nella radice dell'albero al costo di O(log N).
 */