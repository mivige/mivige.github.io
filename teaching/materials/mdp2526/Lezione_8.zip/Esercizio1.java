// Esercizio 1: Logistica di una Flotta Stellare 
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

// 1. Si definisca una classe astratta Astronave 
abstract class Astronave {
    private String codiceIdentificativo;
    private int scudoEnergia;
    private double massa;

    public Astronave(String codiceIdentificativo, int scudoEnergia, double massa) {
        this.codiceIdentificativo = codiceIdentificativo;
        this.scudoEnergia = scudoEnergia;
        this.massa = massa;
    }

    public String getCodiceIdentificativo() { return codiceIdentificativo; }
    public int getScudoEnergia() { return scudoEnergia; }
    public double getMassa() { return massa; }

    // 4. Implementare correttamente equals e hashCode 
    // Questo garantisce che non vi siano navi duplicate con lo stesso codice nell'hangar 
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Astronave astronave = (Astronave) o;
        return Objects.equals(codiceIdentificativo, astronave.codiceIdentificativo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(codiceIdentificativo);
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() + "{" +
                "ID='" + codiceIdentificativo + '\'' +
                ", Scudo=" + scudoEnergia +
                ", Massa=" + massa +
                '}';
    }
}

// 2. Sottoclassi specifiche 
class CacciaIntercettore extends Astronave {
    private int numeroSiluriLaser;

    public CacciaIntercettore(String id, int scudo, double massa, int numeroSiluriLaser) {
        super(id, scudo, massa);
        this.numeroSiluriLaser = numeroSiluriLaser;
    }
}

class IncrociatoreCargo extends Astronave {
    private double capacitaMaxCarico;

    public IncrociatoreCargo(String id, int scudo, double massa, double capacitaMaxCarico) {
        super(id, scudo, massa);
        this.capacitaMaxCarico = capacitaMaxCarico;
    }
}

// 3. Classe generica Hangar 
// Usando Hangar<T> si vincola il tipo staticamente (Bounded Generics) 
class Hangar<T extends Astronave> {
    // Gestisce un insieme di astronavi utilizzando internamente un HashSet 
    private Set<T> flotta = new HashSet<>();

    // Fornire i metodi per inserire un'astronave 
    public void inserisci(T astronave) {
        flotta.add(astronave);
    }

    // Rimuoverla tramite codice identificativo 
    // Usiamo removeIf che è un'operazione sicura e concisa offerta dalle Collection
    public void rimuovi(String codiceIdentificativo) {
        flotta.removeIf(a -> a.getCodiceIdentificativo().equals(codiceIdentificativo));
    }

    // 5. Metodo ottieniNaviPronte() tramite le API Stream 
    public List<T> ottieniNaviPronte() {
        return flotta.stream()
                // Filtro: scudo strettamente superiore a 75 
                .filter(a -> a.getScudoEnergia() > 75)
                // Ordinamento: decrescente per massa 
                // Comparator.comparingDouble ordina in modo crescente, reversed() inverte l'ordine.
                .sorted(Comparator.comparingDouble(Astronave::getMassa).reversed())
                .collect(Collectors.toList());
    }
}

public class Esercizio1 {
    public static void main(String[] args) {
        System.out.println("--- Test Esercizio 1: Flotta Stellare ---");
        
        // Un Hangar non può ospitare una flotta mista se specializzato per soli caccia 
        Hangar<CacciaIntercettore> hangarCaccia = new Hangar<>();
        
        CacciaIntercettore c1 = new CacciaIntercettore("X-WING-01", 80, 12.5, 4);
        CacciaIntercettore c2 = new CacciaIntercettore("TIE-02", 60, 9.0, 2);
        CacciaIntercettore c3 = new CacciaIntercettore("X-WING-03", 90, 14.0, 6);
        CacciaIntercettore c4_duplicato = new CacciaIntercettore("X-WING-01", 100, 12.5, 4);

        hangarCaccia.inserisci(c1);
        hangarCaccia.inserisci(c2);
        hangarCaccia.inserisci(c3);
        hangarCaccia.inserisci(c4_duplicato); // Non verrà inserito grazie a equals/hashCode 

        System.out.println("Navi pronte (Scudo > 75, ordinate per massa decrescente):");
        hangarCaccia.ottieniNaviPronte().forEach(System.out::println);
        
        hangarCaccia.rimuovi("X-WING-03");
        System.out.println("\nDopo la rimozione di X-WING-03:");
        hangarCaccia.ottieniNaviPronte().forEach(System.out::println);
    }
}

/* 💡 RIFLESSIONI DEL TUTOR
 * - Decision Making: Si è scelto un `HashSet` interno alla classe `Hangar` per garantire operazioni
 *                    di add e remove con complessità O(1) e, contemporaneamente, imporre l'unicità dettata dalle 
 *                    specifiche dell'esercizio.
 * 
 * - Alternative: Per l'ordinamento decrescente, in alternativa al costrutto dichiarativo
 *                `Comparator.comparingDouble(...).reversed()`, si sarebbe potuta usare una Lambda esplicita:
 *                `.sorted((a1, a2) -> Double.compare(a2.getMassa(), a1.getMassa()))`. La prima è più idiomatica.
 * 
 * - Pitfalls: Un errore comune è dimenticarsi di fare l'Override congiunto di `equals` e `hashCode`. 
 *             Se si ridefinisce solo `equals`, l'`HashSet` considererà comunque diversi due oggetti con lo 
 *             stesso codice se allocati in aree di memoria differenti.
 * 
 * - Focus: L'uso di `<T extends Astronave>` (Bounded Generics) assicura che l'Hangar sia omogeneo
 *          (può essere istanziato solo per specifici tipi di Astronave) fornendo però ai metodi interni 
 *          tutti i getter derivanti dalla superclasse `Astronave`.
 */