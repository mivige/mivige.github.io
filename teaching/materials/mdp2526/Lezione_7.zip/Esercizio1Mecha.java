// Esercizio 1: Sistema di Configurazione Mecha (Builder e Strategy)

// Interfaccia funzionale per modellare la strategia di movimento 
@FunctionalInterface
interface StrategiaMovimento {
    void muovi(String modello);
}

// Implementazione concreta dello Strategy: Movimento su cingoli 
class MovimentoCingolato implements StrategiaMovimento {
    @Override
    public void muovi(String modello) {
        System.out.println("Il mecha " + modello + " avanza cingolando sul terreno.");
    }
}

// Implementazione concreta dello Strategy: Movimento in volo 
class MovimentoJetpack implements StrategiaMovimento {
    @Override
    public void muovi(String modello) {
        System.out.println("Il mecha " + modello + " vola bypassando gli ostacoli.");
    }
}

// Classe complessa Mecha che utilizza i pattern Builder e Strategy 
class Mecha {
    private String modello; // Parametro obbligatorio 
    private String armaPrincipale; // Parametro opzionale 
    private int corazzatura; // Parametro opzionale 

    // Composizione utilizzata per lo Strategy Pattern, evitando ereditarietà rigida 
    private StrategiaMovimento strategiaMovimento;

    // Costruttore privato: impedisce istanziazioni esterne che aggirano il Builder 
    private Mecha(Builder builder) {
        this.modello = builder.modello;
        this.armaPrincipale = builder.armaPrincipale;
        this.corazzatura = builder.corazzatura;
    }

    // Metodo che delega l'esecuzione del comportamento alla strategia attualmente impostata 
    public void eseguiMovimento() {
        if (strategiaMovimento != null) {
            strategiaMovimento.muovi(this.modello); // Delega
        } else {
            System.out.println("Errore: Nessuna strategia di movimento impostata per " + modello);
        }
    }

    // Setter per modificare il comportamento dinamicamente a runtime 
    public void setStrategiaMovimento(StrategiaMovimento sm) {
        this.strategiaMovimento = sm;
    }

    @Override
    public String toString() {
        return "Mecha [Modello=" + modello + ", Arma=" + armaPrincipale + ", Corazzatura=" + corazzatura + "]";
    }

    // Classe interna statica per implementare il Builder Pattern 
    public static class Builder {
        private String modello;
        private String armaPrincipale = "Pugni robotici"; // Valore di default fornito dalla traccia 
        private int corazzatura = 100; // Valore di default fornito dalla traccia 

        // Costruttore del Builder che accetta unicamente i campi obbligatori 
        public Builder(String modello) {
            this.modello = modello;
        }

        // I metodi setter del Builder ritornano 'this' per consentire la fluent interface 
        public Builder setArmaPrincipale(String arma) {
            this.armaPrincipale = arma;
            return this; // Permette di concatenare le chiamate 
        }

        public Builder setCorazzatura(int corazzatura) {
            this.corazzatura = corazzatura;
            return this;
        }

        // Metodo terminale della catena: genera e restituisce il prodotto finale
        public Mecha build() {
            return new Mecha(this);
        }
    }
}

// Classe che esegue i test integrati richiesti
public class Esercizio1Mecha {
    public static void main(String[] args) {
        System.out.println("--- TEST ESERCIZIO 1: MECHA ---");
        
        // Creazione di oggetti complessi tramite Fluent Interface 
        Mecha gundam = new Mecha.Builder("RX-78-2")
                .setArmaPrincipale("Fucile a Raggi")
                .setCorazzatura(250)
                .build();

        Mecha zaku = new Mecha.Builder("MS-06") // Le proprietà opzionali assumeranno i default
                .build();

        System.out.println(gundam);
        System.out.println(zaku);

        // Inizializzazione delle strategie di movimento 
        StrategiaMovimento movCingolato = new MovimentoCingolato();
        StrategiaMovimento movJetpack = new MovimentoJetpack();

        // Applicazione dinamica delle strategie 
        System.out.println("\nAssegnazione dei movimenti iniziali:");
        gundam.setStrategiaMovimento(movJetpack);
        gundam.eseguiMovimento();

        zaku.setStrategiaMovimento(movCingolato);
        zaku.eseguiMovimento();

        // Dimostrazione del cambio di strategia a runtime (Vantaggio dello Strategy Pattern) 
        System.out.println("\nCambio di terreno! Lo Zaku attiva i propulsori di emergenza:");
        zaku.setStrategiaMovimento(movJetpack);
        zaku.eseguiMovimento();
    }
}

/* 💡 RIFLESSIONI DEL TUTOR
 *
 * Decision Making: L'architettura adottata separa nettamente le responsabilità. Per la creazione, 
 *                  abbiamo implementato un Builder statico interno per supportare in modo leggibile parametri 
 *                  multipli e opzionali, evitando antipattern costruttivi. Per la logica di movimento, 
 *                  lo Strategy Pattern garantisce la variazione dinamica dei comportamenti, isolandoli in interfacce 
 *                  tramite composizione anziché usare una rigida ereditarietà multipla.
 *
 * Alternative: Essendo `StrategiaMovimento` un'interfaccia funzionale dotata del solo metodo `muovi`, 
 *              al momento di chiamare `setStrategiaMovimento()` si potrebbero passare direttamente 
 *              funzioni Lambda nel `main` in linea, evitando di scrivere le classi fisiche `MovimentoCingolato` 
 *              o `MovimentoJetpack` se l'algoritmo al loro interno è banale.
 *
 * Pitfalls (Trappole): 
 * 1. Omettere il modificatore `private` sul costruttore base di `Mecha`. Questo errore frequente 
 *    distrugge il pattern perché rende legalmente possibile invocare `new Mecha()` dall'esterno, saltando 
 *    il processo di costruzione tutelato del Builder.
 * 2. Scordarsi di usare l'istruzione `return this;` all'interno dei metodi del Builder. In sua assenza 
 *    il concatenamento a cascata si interrompe in fase di compilazione.
 *
 * Focus: L'obiettivo centrale è il "Disaccoppiamento Creazionale e Comportamentale".
 *        Applicare contemporaneamente due design pattern distinti dimostra come sia possibile isolare
 *        in modo elegante l'istanziazione dall'azione a runtime.
 */