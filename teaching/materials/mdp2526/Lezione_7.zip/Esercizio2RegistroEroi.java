// Esercizio 2: Piattaforma Analitica di Squadre (Generics, Functional Interfaces, Stream)

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collectors;

// Interfaccia per garantire il contratto minimo sugli oggetti gestiti dal Registro 
interface Eroe {
    String getNome();
    String getFazione();
    int getPotenza();
}

// Classe modello utilizzata esclusivamente per dimostrare e testare il registro
class EroeConcreto implements Eroe {
    private String nome;
    private String fazione;
    private int potenza;

    public EroeConcreto(String nome, String fazione, int potenza) {
        this.nome = nome;
        this.fazione = fazione;
        this.potenza = potenza;
    }

    @Override public String getNome() { return nome; }
    @Override public String getFazione() { return fazione; }
    @Override public int getPotenza() { return potenza; }

    @Override
    public String toString() {
        return nome + " [" + fazione + ", lvl: " + potenza + "]";
    }
}

// Struttura dati tipizzata. Il Bounded Generic "extends Eroe" forza T a rispettare l'interfaccia 
class RegistroEroi<T extends Eroe> {
    
    // Collezione di base su cui applicare le Stream pipeline 
    private List<T> personaggi;

    public RegistroEroi() {
        this.personaggi = new ArrayList<>();
    }

    // Inserisce il generico parametrizzato in lista 
    public void aggiungiPersonaggio(T p) {
        this.personaggi.add(p);
    }

    // Stream complessa: raggruppa la stream in una Map utilizzando una chiave e mappando il valore via media 
    public Map<String, Double> analizzaFazioni() {
        return personaggi.stream()
            .collect(Collectors.groupingBy(
                Eroe::getFazione, // Classifier: raggruppa per il nome della fazione
                Collectors.averagingInt(Eroe::getPotenza) // Downstream: calcola la media su attributi interi 
            ));
    }

    // Filtraggio generico basato su Predicate, la Functional Interface valuterà una condizione logica a runtime 
    public List<T> filtraEroi(Predicate<T> filtro) {
        return personaggi.stream()
            .filter(filtro) // Valutazione pigra
            .collect(Collectors.toList());
    }

    // Collettore annidato: raggruppa per fazione e poi applica una ricerca del massimo tramite Comparator 
    // maxBy restituisce sempre Optional in caso la lista associata alla chiave fazione sia vuota 
    public Map<String, Optional<T>> getEroeTopPerFazione() {
        return personaggi.stream()
            .collect(Collectors.groupingBy(
                Eroe::getFazione,
                Collectors.maxBy(Comparator.comparingInt(Eroe::getPotenza)) // Comparator compatto usando method reference 
            ));
    }
}

// Classe che esegue i test integrati richiesti
public class Esercizio2RegistroEroi {
    public static void main(String[] args) {
        System.out.println("--- TEST ESERCIZIO 2: PIATTAFORMA ANALITICA EROI ---");

        // Istanziazione del registro con il tipo concreto collegato al bounded generic
        RegistroEroi<EroeConcreto> registro = new RegistroEroi<>();

        registro.aggiungiPersonaggio(new EroeConcreto("Iron Man", "Avengers", 850));
        registro.aggiungiPersonaggio(new EroeConcreto("Thor", "Avengers", 950));
        registro.aggiungiPersonaggio(new EroeConcreto("Capitan America", "Avengers", 800));

        registro.aggiungiPersonaggio(new EroeConcreto("Batman", "Justice League", 700));
        registro.aggiungiPersonaggio(new EroeConcreto("Superman", "Justice League", 1000));
        registro.aggiungiPersonaggio(new EroeConcreto("Wonder Woman", "Justice League", 900));

        // Test 1: analizzaFazioni
        System.out.println("\n> Analisi delle Fazioni (Media Potenza):");
        Map<String, Double> medie = registro.analizzaFazioni();
        medie.forEach((fazione, media) -> 
            System.out.println("- " + fazione + " (Power AVG): " + media)
        );

        // Test 2: filtraEroi tramite una funzione Lambda passata al Predicate
        System.out.println("\n> Filtro Eroi (Potenza > 850):");
        List<EroeConcreto> over850 = registro.filtraEroi(e -> e.getPotenza() > 850);
        over850.forEach(e -> System.out.println("- " + e));

        // Test 3: getEroeTopPerFazione combinando groupingBy e maxBy
        System.out.println("\n> Eroe più potente per Fazione:");
        Map<String, Optional<EroeConcreto>> topEroi = registro.getEroeTopPerFazione();
        topEroi.forEach((fazione, optEroe) -> {
            // Estrazione sicura del valore presente nell'Optional
            optEroe.ifPresent(eroe -> System.out.println("- " + fazione + " -> " + eroe.getNome() + " (Lvl: " + eroe.getPotenza() + ")"));
        });
    }
}

/* 💡 RIFLESSIONI DEL TUTOR
 *
 * Decision Making: L'utilizzo dei Bounded Generics (`<T extends Eroe>`) garantisce che il registro 
 *                  permetta a compile-time solo l'inserimento di oggetti che rispettano il contratto dell'interfaccia 
 *                  Eroe. La collezione interna è stata mappata come `List` e istanziata come `ArrayList`,
 *                  una scelta ad altissime prestazioni in termini iterativi in scenari read-heavy come le Stream API.
 *
 * Alternative: In versioni moderne di Java (14+), invece della tradizionale classe `EroeConcreto`,
 *              sarebbe stato sintatticamente più pulito utilizzare il costrutto `record` (`record EroeConcreto(...) implements Eroe`), 
 *              per abbattere interamente il boilerplate code dei metodi getters per nome, fazione e potenza.
 *
 * Pitfalls (Trappole):
 * 1. Durante l'elaborazione dei Collector downstream, scordare che i campi numerici gestiti all'interno
 *    di calcoli (somme, medie) impongono l'utilizzo di mappatori per primitivi come `Collectors.averagingInt()`.
 * 2. Un classico errore fatale sui Generics è non rendersi conto che `Collectors.maxBy` emette 
 *    tassativamente un tipo `Optional` a protezione di NullPointerException per liste vuote.
 *    Dimenticarsi di configurare il tipo restituito della Mappa come `Map<String, Optional<T>>`
 *    causa un immediato errore di compilazione.
 *
 * Focus: Evitare costrutti imperativi ciclici per delegare al core di Java la costruzione di 
 *        Map complesse attraverso programmazione dichiarativa reattiva..
 */