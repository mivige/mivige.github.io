// ESERCIZIO 3: Utility per Liste Generiche

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

class ListUtility {

    // Metodo statico generico per filtrare elementi
    public static <T> List<T> filtra(List<T> lista, Predicate<T> filtro) {
        List<T> risultato = new ArrayList<>();
        for (T elemento : lista) {
            // Se il predicato restituisce true, l'elemento viene aggiunto
            if (filtro.test(elemento)) {
                risultato.add(elemento);
            }
        }
        return risultato;
    }

    // Metodo statico generico con vincolo di comparabilità
    // <T extends Comparable<T>> garantisce che T abbia il metodo compareTo
    public static <T extends Comparable<T>> T trovaMinimo(List<T> lista) {
        if (lista == null || lista.isEmpty()) {
            return null;
        }

        T minimo = lista.get(0);
        for (T elemento : lista) {
            // compareTo < 0 significa che l'elemento è più piccolo del minimo attuale
            if (elemento.compareTo(minimo) < 0) {
                minimo = elemento;
            }
        }
        return minimo;
    }
}

public class Esercizio3 {
    public static void main(String[] args) {
        List<Integer> numeri = List.of(10, 5, 20, 3, 15);

        // Test Filtro: solo numeri pari
        List<Integer> pari = ListUtility.filtra(numeri, n -> n % 2 == 0);
        System.out.println("Numeri pari: " + pari);

        // Test Minimo
        Integer min = ListUtility.trovaMinimo(numeri);
        System.out.println("Valore minimo: " + min);

        // Test con Stringhe (che implementano Comparable)
        List<String> parole = List.of("Zebra", "Alpha", "Mela");
        System.out.println("Stringa minima: " + ListUtility.trovaMinimo(parole));
    }
}

/*
💡 RIFLESSIONI DEL TUTOR:
1. Decision Making: Ho utilizzato parametri di tipo generico <T> per rendere i metodi riutilizzabili con qualsiasi 
   tipo di dato (Integer, String, oggetti custom).
2. Alternative: Per il metodo filtra, avremmo potuto usare le Stream API: lista.stream().filter(filtro).toList(). 
   Tuttavia, l'implementazione manuale è utile per capire la logica dei Generics.
3. Pitfalls: Un errore comune è non gestire la lista vuota in trovaMinimo, il che causerebbe una IndexOutOfBoundsException.
4. Focus: Il vincolo <T extends Comparable<T>> è fondamentale. Senza di esso, Java non permetterebbe di chiamare 
   .compareTo() su un oggetto di tipo T, poiché la classe Object non lo possiede.
*/