// ESERCIZIO 4: Gestione Log Eventi

import java.time.LocalDateTime;
import java.util.TreeSet;
import java.util.function.Consumer;

class LogEntry implements Comparable<LogEntry> {
    private final LocalDateTime timestamp;
    private final String messaggio;

    public LogEntry(LocalDateTime timestamp, String messaggio) {
        this.timestamp = timestamp;
        this.messaggio = messaggio;
    }

    public LocalDateTime getTimestamp() { return timestamp; }

    @Override
    public int compareTo(LogEntry altro) {
        // Ordinamento decrescente: dal più recente al meno recente
        // Invertiamo l'ordine classico (this vs altro) per ottenere il reverse
        return altro.timestamp.compareTo(this.timestamp);
    }

    @Override
    public String toString() {
        return String.format("[%s] %s", timestamp, messaggio);
    }
}

class RegistroEventi {
    // Il TreeSet userà il compareTo di LogEntry per ordinare automaticamente
    private final TreeSet<LogEntry> logSet;

    public RegistroEventi() {
        this.logSet = new TreeSet<>();
    }

    public void aggiungiLog(LogEntry log) {
        logSet.add(log);
    }

    // Accetta un'azione da compiere su ogni log (es. stampa, salvataggio)
    public void eseguiAzioneSuLog(Consumer<LogEntry> action) {
        for (LogEntry log : logSet) {
            action.accept(log);
        }
    }
}

public class Esercizio4 {
    public static void main(String[] args) {
        RegistroEventi registro = new RegistroEventi();

        // Simulazione log in tempi diversi
        registro.aggiungiLog(new LogEntry(LocalDateTime.now().minusHours(1), "Errore Database"));
        registro.aggiungiLog(new LogEntry(LocalDateTime.now(), "Sistema Avviato"));
        registro.aggiungiLog(new LogEntry(LocalDateTime.now().minusDays(1), "Backup completato"));

        System.out.println("Cronologia Log (Recenti -> Vecchi):");
        // Usiamo un Consumer per stampare
        registro.eseguiAzioneSuLog(log -> System.out.println("LOG: " + log));
        
        // Esempio di un'azione diversa: contare i messaggi lunghi
        registro.eseguiAzioneSuLog(log -> {
            if (log.getTimestamp().isBefore(LocalDateTime.now().minusMinutes(30))) {
                System.out.println("Alert: Rilevato log datato.");
            }
        });
    }
}

/*
💡 RIFLESSIONI DEL TUTOR:
1. Decision Making: TreeSet è la scelta ideale per i log perché garantisce che siano sempre ordinati 
   temporalmente senza dover chiamare List.sort() ogni volta.
2. Alternative: Si potrebbe usare un Comparator.reverseOrder() se non volessimo modificare il compareTo 
   originale della classe LogEntry.
3. Pitfalls: Se due log hanno esattamente lo stesso timestamp, il TreeSet ne terrà solo uno (perché compareTo 
   restituirebbe 0). In un sistema reale, bisognerebbe aggiungere un criterio di spareggio (es. ID o messaggio).
4. Focus: L'uso di Consumer<T> permette di implementare il pattern "Inversion of Control": il registro fornisce 
   i dati, ma è l'utilizzatore a decidere cosa farne (stampa, log su file, filtraggio).
*/