// ESERCIZIO 1: Sistema di Gestione Dispositivi Smart

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;

class Dispositivo implements Comparable<Dispositivo> {
    private final String codice;
    private final String nome;
    private final double consumo;

    public Dispositivo(String codice, String nome, double consumo) {
        this.codice = codice;
        this.nome = nome;
        this.consumo = consumo;
    }

    public String getCodice() { return codice; }
    public String getNome() { return nome; }
    public double getConsumo() { return consumo; }

    // Implementazione equals basata esclusivamente sul codice univoco
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Dispositivo that = (Dispositivo) o;
        return Objects.equals(codice, that.codice); // Due dispositivi sono uguali se hanno lo stesso ID
    }

    // HashCode deve essere coerente con equals per funzionare correttamente in un HashSet
    @Override
    public int hashCode() {
        return Objects.hash(codice);
    }

    @Override
    public String toString() {
        return String.format("[%s] %s - Consumo: %.2fW", codice, nome, consumo);
    }

    // Ordinamento naturale per SmartHomeOrdinata (TreeSet)
    @Override
    public int compareTo(Dispositivo altro) {
        if (equals(altro)){
            return 0; // Se sono considerati uguali da equals(), devono essere considerati uguali anche da compareTo()
        }
        // Confronto primario sul consumo
        int compConsumo = Double.compare(this.consumo, altro.consumo);
        if (compConsumo != 0) {
            return compConsumo;
        }
        // Confronto secondario sul nome in caso di parità di consumo
        return this.nome.compareTo(altro.nome);
    }
}

class SmartHome {
    protected Set<Dispositivo> dispositivi;

    public SmartHome() {
        // HashSet garantisce l'unicità tramite equals() e hashCode()
        this.dispositivi = new HashSet<>();
    }

    public void aggiungiDispositivo(Dispositivo d) {
        dispositivi.add(d);
    }

    public void stampaDispositivi() {
        dispositivi.forEach(System.out::println);
    }
}

class SmartHomeOrdinata extends SmartHome {
    public SmartHomeOrdinata() {
        // TreeSet mantiene gli elementi ordinati secondo compareTo()
        this.dispositivi = new TreeSet<>();
    }
}

public class Esercizio1 {
    public static void main(String[] args) {
        System.out.println("--- Test HashSet (Nessun duplicato per Codice) ---");
        SmartHome casa = new SmartHome();
        casa.aggiungiDispositivo(new Dispositivo("A1", "Lampada", 10.5));
        casa.aggiungiDispositivo(new Dispositivo("A1", "Lampada Clone", 10.5)); // Duplicato: non verrà inserito
        casa.aggiungiDispositivo(new Dispositivo("B2", "Forno", 2000.0));
        casa.stampaDispositivi();

        System.out.println("\n--- Test TreeSet (Ordinamento Consumo/Nome) ---");
        SmartHomeOrdinata casaOrdinata = new SmartHomeOrdinata();
        casaOrdinata.aggiungiDispositivo(new Dispositivo("X", "Z-Device", 50.0));
        casaOrdinata.aggiungiDispositivo(new Dispositivo("X", "Z-Device Clone", 50.0));
        casaOrdinata.aggiungiDispositivo(new Dispositivo("Y", "A-Device", 50.0)); // Stesso consumo, ordine alfabetico
        casaOrdinata.aggiungiDispositivo(new Dispositivo("W", "Eco-Device", 10.0));
        casaOrdinata.stampaDispositivi();
    }
}

/*
💡 RIFLESSIONI DEL TUTOR:
   Pitfalls: L'errore più comune è implementare equals() ma dimenticarsi hashCode(). In quel caso, HashSet 
   accetterebbe duplicati perché non riuscirebbe a "trovare" l'oggetto nel bucket corretto.
   Focus: La coerenza tra compareTo() e equals() è vitale. Se compareTo() restituisce 0 per due oggetti con ID diversi, 
   il TreeSet li considererà duplicati e ne scarterà uno, anche se equals() dice che sono diversi.
*/