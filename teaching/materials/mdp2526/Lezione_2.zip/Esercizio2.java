// ESERCIZIO 2: Pipeline di Elaborazione Stringhe

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

class TextProcessor {
    // Lista di funzioni che accettano String e restituiscono String
    private final List<Function<String, String>> pipeline;

    public TextProcessor() {
        this.pipeline = new ArrayList<>();
    }

    public void aggiungiFase(Function<String, String> f) {
        pipeline.add(f);
    }

    public String elabora(String input) {
        String result = input;
        for (Function<String, String> fase : pipeline) {
            // Applica la trasformazione corrente al risultato della precedente
            result = fase.apply(result);
        }
        return result;
    }
}

public class Esercizio2 {
    public static void main(String[] args) {
        TextProcessor tp = new TextProcessor();

        // 1. Rimozione spazi iniziali/finali tramite Method Reference
        tp.aggiungiFase(String::trim);

        // 2. Maiuscolo tramite Lambda
        tp.aggiungiFase(s -> s.toUpperCase());

        // 3. Sostituzione spazi con underscore
        tp.aggiungiFase(s -> s.replace(" ", "_"));

        // 4. Aggiunta prefisso
        tp.aggiungiFase(s -> "[PROCESSED] " + s);

        String input = "   java collections and functions   ";
        String output = tp.elabora(input);

        System.out.println("Input: '" + input + "'");
        System.out.println("Output: " + output);
    }
}

/*
💡 RIFLESSIONI DEL TUTOR:
1. Decision Making: L'uso di una List<Function> permette di creare una pipeline dinamica dove l'ordine delle fasi 
   è garantito (a differenza di un Set).
2. Alternative: Avremmo potuto usare il metodo predefinito delle interfacce funzionali functionA.andThen(functionB), 
   che concatena due funzioni in una singola operazione senza iterare manualmente su una lista.
3. Pitfalls: Attenzione all'ordine! Se mettiamo il prefisso [PROCESSED] prima del trim, rischiamo che un eventuale 
   trim successivo possa alterare la formattazione desiderata se non gestita bene.
4. Focus: L'interfaccia Function<T, R> è la base della programmazione funzionale in Java; permette di separare 
   l'algoritmo (elabora) dai dati (le specifiche trasformazioni).
*/