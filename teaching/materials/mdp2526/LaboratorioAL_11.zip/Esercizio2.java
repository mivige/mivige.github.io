import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.BiFunction;
import java.util.function.Predicate;

class MultiMappa<K, V> implements Iterable<MultiMappa.Elemento>{
	
	private Map<K, HashSet<V>> mappa;
	
	public MultiMappa() {
		// Ogni chiave della multimappa punta a un insieme di valori.
		mappa = new HashMap<K, HashSet<V>>();
	}

	// Associa un valore alla chiave specificata.
	// Se la chiave esiste già, il valore viene aggiunto all'insieme già presente.
	public void put(K k, V v) {
		HashSet<V> insieme;
		
		if (mappa.containsKey(k)) {
			insieme = mappa.get(k);
		} else {
			insieme = new HashSet<V>();
		}
		insieme.add(v);
		mappa.put(k, insieme);
	}

	// Restituisce l'insieme dei valori associati alla chiave.
	public HashSet<V> get(K k) {
		return mappa.get(k);
	}

	// Restituisce l'insieme di tutte le chiavi presenti nella multimappa.
	public Set<K> keySet() {
		return mappa.keySet();
	}

	// Aggiunge alla multimappa corrente tutte le coppie chiave-valore contenute
	// nella multimappa passata come parametro.
	public void putAll(MultiMappa<K, V> mappa) {
		for (K k : mappa.keySet()) {
			this.mappa.put(k, mappa.get(k));
		}
	}

	// Rimuove dalla multimappa corrente tutte le chiavi presenti nella multimappa
	// passata come parametro.
	public void removeAll(MultiMappa<K, V> mappa) {
		for (K k : mappa.keySet()) {
			this.mappa.remove(k);
		}
	}

	@Override
	public String toString() {
		// Rappresentazione testuale utile per il debug e per gli esempi a console.
		String returnStr = "";
		for (K k: mappa.keySet()) {
			returnStr +=k+ " "+ mappa.get(k)+"\n";
		}
		return returnStr;
	}

	// Restituisce solo i valori associati alla chiave k che soddisfano il predicato p.
	public Set<V> get(K k, Predicate<V> p) {
		Set<V> orig = mappa.get(k);
		if (orig == null) {
			return null;
		}
		HashSet<V> retValue  = new HashSet<V>();
		orig.forEach(v -> {
			if(p.test(v)){
				retValue.add(v);
				}
			});
		
		return retValue;
	}

	// Restituisce l'elenco di tutti i valori presenti nella multimappa.
	// Poiché internamente i valori sono memorizzati in insiemi, non ci sono duplicati
	// all'interno della stessa chiave; l'elenco può però contenere valori uguali
	// provenienti da chiavi diverse.
	public List<V> values() {
		List<V> elenco = new ArrayList<V>();
		for (K k : mappa.keySet()) {
			elenco.addAll(mappa.get(k));
		}
		return elenco;
	}

	// Restituisce l'insieme di tutti i valori contenuti nella multimappa.
	public Set<V> valueSet() {
		Set<V> insieme = new HashSet<V>();
		for (Set<V> sv : mappa.values()) {
			insieme.addAll(sv);
		}
		return insieme;
	}

	// Trasforma ogni coppia (k, v) in una nuova coppia (k, z), dove z è il valore
	// restituito dalla funzione bf applicata alla chiave e al valore corrente.
	public  <Z> MultiMappa<K, Z> transformToMultimappa(BiFunction<K, V, Z> bf) {

		MultiMappa<K, Z> result = new MultiMappa<K, Z>();
		for (K k : mappa.keySet()) {
			for (V v : mappa.get(k)) {
				Z z = bf.apply(k, v);
				result.put(k, z);
			}
		}
		return result;
	}

	// Sostituisce ogni valore v con un nuovo valore v' dello stesso tipo,
	// calcolato tramite la funzione bf(k, v).
	public void mapEach(BiFunction<K, V, V> bf) {
		Map<K, HashSet<V>> nuovaMappa = new HashMap<K, HashSet<V>>();

		for (K k : mappa.keySet()) {
			HashSet<V> nuoviValori = new HashSet<V>();
			for (V v : mappa.get(k)) {
				nuoviValori.add(bf.apply(k, v));
			}
			nuovaMappa.put(k, nuoviValori);
		}
		mappa = nuovaMappa;
	}

	// Classe interna che rappresenta una coppia della multimappa durante l'iterazione.
	public class Elemento {
		private K chiave;
		private Set<V> valore;
		
		public Elemento(K chiave, Set<V> valore) {
			this.chiave=chiave;
			this.valore= valore;
		}
		public K getChiave() {
			return chiave;
		}

		public Set<V> getValore() {
			return valore;
		}
	}

	@Override
	public Iterator<MultiMappa.Elemento> iterator(){
		// L'iteratore scorre le chiavi della multimappa e, per ogni chiave,
		// restituisce l'oggetto Elemento corrispondente.
		return new Iterator<MultiMappa.Elemento>() {

			private final Iterator<K> chiavi = mappa.keySet().iterator();

			@Override
			public boolean hasNext() {
				return chiavi.hasNext();
			}

			@Override
			public MultiMappa.Elemento next() {
				K chiaveCorrente = chiavi.next();
				return new Elemento(chiaveCorrente, mappa.get(chiaveCorrente));
			}
		};
	}
}

public class Esercizio2 {

	public static void main(String[] args) {
		
		MultiMappa<String, Integer> mymappa = new MultiMappa<String, Integer>();
		MultiMappa<Integer,String> mymappaInv = new MultiMappa<Integer, String>();

		// Esempio di popolamento della multimappa.
		mymappa.put("AL", 35);
		mymappa.put("AL", 36);
		mymappa.put("AL", 300);
		mymappa.put("A", 36);
		mymappa.put("A", 36);
		mymappa.put("A", 369);

        System.out.println("Valori nella multimappa:");
		System.out.println(mymappa.values());

        System.out.println("\nChiavi associate ai valori:");
		System.out.println( mymappa.transformToMultimappa((k,v)->""+k+v));
		
		// Esempio del filtro sul valore associato a una chiave.
        System.out.println("\nValori associati alla chiave 'AL' che sono minori di 100:");
		System.out.println(mymappa.get("AL", x->x<100));
		
        System.out.println("\nIterazione sulla multimappa:");
		Iterator<MultiMappa.Elemento> iter = mymappa.iterator();
		while(iter.hasNext()) {
			System.out.println(iter.next().getValore());
		}

		// Esempio della multimappa inversa.
		mymappaInv.put(36,"cuai");
		mymappaInv.put(36,"cuais");
		mymappaInv.put(38,"trentotto");
        System.out.println("\nMultimappa inversa:");
		System.out.println(mymappaInv);

		// Esempio di trasformazione in-place dei valori.
		mymappaInv.mapEach((k, v) -> v.toUpperCase());
        System.out.println("Multimappa inversa dopo trasformazione in-place:");
		System.out.println(mymappaInv);
	}
}