import java.util.Objects;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

class Canzone implements Comparable<Canzone>{

	// Proprietà final della canzone: nome e autore non possono essere modificati
	private final String nome;
	private final String autore;
	
	public Canzone(String nome, String autore) {
		this.nome= nome;
		this.autore = autore;
	}

	public String getNome() {
		return nome;
	}

	public String getAutore() {
		return autore;
	}

	/**
	 * Metodo hashCode - FONDAMENTALE per HashSet
	 * Calcola un valore hash basato su nome e autore della canzone.
	 * Usa il numero primo 31 per combinare i valori hash.
	 * Due canzoni uguali (stesso nome e autore) avranno lo stesso hashCode.
	 * @return il valore hash della canzone
	 */
	@Override
	public int hashCode() {
		
		int result = nome == null? 0 : nome.hashCode();
		result = 31*result+autore.hashCode();
		return result;
		
	}

	/**
	 * Metodo equals - FONDAMENTALE per HashSet
	 * Verifica se due oggetti Canzone sono uguali confrontando nome e autore.
	 * È necessario implementare equals insieme a hashCode per garantire:
	 * - Se equals(obj) = true, allora hashCode() deve restituire lo stesso valore
	 * - Se due oggetti sono uguali, HashSet li considera duplicati
	 * @param obj l'oggetto da confrontare con questa canzone
	 * @return true se nome e autore sono uguali, false altrimenti
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof Canzone)) {
			return false;
		}
		Canzone other = (Canzone) obj;
		return Objects.equals(autore, other.autore) && Objects.equals(nome, other.nome);
	}

	/**
	 * Metodo compareTo - FONDAMENTALE per TreeSet
	 * Definisce l'ordine naturale delle canzoni:
	 * 1. Ordinamento primario: per nome della canzone
	 * 2. Ordinamento secondario: per nome dell'autore (in caso di nomi uguali)
	 * @param canzone la canzone da confrontare con questa
	 * @return un valore negativo se this < canzone, positivo se this > canzone, 0 se uguali
	 */
	@Override
	public int compareTo(Canzone canzone) {
		if (canzone==null) return 1;//e' maggiore canzone
		if (this.equals(canzone)) return 0;
		
		return nome.equals(canzone.getNome())? autore.compareTo(canzone.getAutore()):nome.compareTo(canzone.getNome());
	}

	@Override
	public String toString() {
		return "Canzone [nome=" + nome + ", autore=" + autore + "]\n";
	}
}


/**
 * Utilizza HashSet per memorizzare le canzoni senza ordine particolare.
 * HashSet impedisce automaticamente i duplicati grazie ai metodi equals e hashCode.
 */
class Raccolta {
	
	// Insieme di canzoni - protected per permettere a RaccoltaOrdinata di accedervi
	protected Set<Canzone> canzoni;
	
	public Raccolta(Set<Canzone> canzoni) {
	this.canzoni = new HashSet<Canzone>(canzoni);
	}
	
	/**
	 * Metodo toString - rappresentazione in stringa della raccolta
	 * Itera su tutte le canzoni e le aggiunge a uno StringBuilder
	 * @return una stringa che contiene tutte le canzoni della raccolta
	 */
	@Override
	public String toString() {
		
	StringBuilder sb = new StringBuilder();
	
		canzoni.forEach(x -> sb.append(x));
		return sb.toString();
	}

	/**
	 * Costruttore vuoto
	 * Serve a RaccoltaOrdinata per inizializzare un HashSet prima di convertirlo in TreeSet
	 */
	public Raccolta() {
	}
}


/**Raccolta di canzoni ordinate
 * Estende Raccolta e utilizza TreeSet al posto di HashSet.
 * TreeSet mantiene automaticamente le canzoni ordinate secondo il metodo compareTo
 * della classe Canzone (ordinamento per nome, poi per autore).
 */
class RaccoltaOrdinata extends Raccolta {
	RaccoltaOrdinata(Set<Canzone> canzoni){
		super();
		// TreeSet ordina automaticamente le canzoni secondo compareTo
		this.canzoni = new TreeSet<Canzone>(canzoni);
	}
}

public class Esercizio1 {

	public static void main(String[] args) {
		// Creiamo un HashSet di canzoni per il test
		Set<Canzone> ts = new HashSet<Canzone>();
		
		// Aggiungiamo varie canzoni, incluso un duplicato ("Cuore Matto" di Little Tony)
		ts.add(new Canzone("Jailhouse Rock","Elvis"));
		ts.add(new Canzone("Cuore Matto", "Little Tony"));
		ts.add(new Canzone("Cuore Matto", "Little Tony")); // Questo sarà un duplicato
		ts.add(new Canzone("Cuore Matto", "Little Tony")); // Questo sarà un duplicato
		ts.add(new Canzone("Cuore Matto","Big Tony"));     // Questo è diverso (autore diverso)
		ts.add(new Canzone("Trapezio NO","Il Mac"));

		// Creiamo una RaccoltaOrdinata: le canzoni saranno ordinate per nome, poi per autore
		System.out.println("Raccolta ordinata:");
		Raccolta r = new RaccoltaOrdinata(ts);
		System.out.println(r.toString());

		// Creiamo una Raccolta standard (non ordinata)
		System.out.println("Raccolta non ordinata:");
		Raccolta s = new Raccolta(ts);
		System.out.println(s.toString());
	}
}