// Esercizio 2: Analizzatore di Testo e Frequenza Parole
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

class AnalizzatoreTesto {
    private List<String> righe;

    public AnalizzatoreTesto(List<String> righe) {
        this.righe = righe;
    }

    public Map<String, Long> mappaFrequenzaTermini() {
        return righe.stream() // Apre il flusso sequenziale di partenza basato sulla Lista di stringhe (righe intere)
            // flatMap frammenta ogni riga in array di singole parole e poi "appiattisce" tutti gli array in un unico Stream coerente
            // La regex \\W+ isola le parole scartando qualsiasi carattere non-word (spazi, virgole, punti)
            .flatMap(riga -> Arrays.stream(riga.split("\\W+")))
            // Mappatura per neutralizzare l'impatto delle maiuscole/minuscole nel conteggio
            .map(String::toLowerCase)
            // Predicato logico: scarta token vuoti e stringhe troppo brevi
            .filter(parola -> !parola.isEmpty() && parola.length() >= 3)
            // Operatore terminale: raggruppa le chiavi (la parola stessa identificata con Function.identity())
            // e riduce i valori ad un conteggio sommativo (Collectors.counting()) per ciascuna chiave
            .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
    }
}

public class Esercizio2AnalizzatoreTesto {
    public static void main(String[] args) {
        List<String> testo = List.of(
            "Nel mezzo del cammin di nostra vita",
            "mi ritrovai per una selva oscura,",
            "ché la diritta via era smarrita.",
            "Ah quanto a dir qual era è cosa dura",
            "esta selva selvaggia e aspra e forte"
        );

        AnalizzatoreTesto analizzatore = new AnalizzatoreTesto(testo);
        Map<String, Long> frequenze = analizzatore.mappaFrequenzaTermini();

        System.out.println("--- Frequenza Termini Estratti ---");
        // Convertiamo le Map.Entry in uno stream solo per ordinare l'output finale in base ai valori (frequenza)
        frequenze.entrySet().stream()
            .sorted(Map.Entry.<String, Long>comparingByValue().reversed())
            .forEach(entry -> System.out.println(entry.getKey() + " -> " + entry.getValue()));
    }
}

/*
💡 RIFLESSIONI DEL TUTOR

Decision Making: Ho scelto l'espressione regolare `\\W+` all'interno del metodo `split`. Essa rappresenta la scelta ottimale nel parsing 
                 di un testo perché mappa qualsiasi sequenza di uno o più caratteri di interpunzione o whitespace, evitando così di dover 
                 scrivere un tokenizer manuale complesso.

Alternative: Invece di `Function.identity()`, molti studenti scrivono `parola -> parola`. Pur essendo valido, l'uso di `Function.identity()` 
             è da considerarsi best practice in termini di leggibilità e stile funzionale in Java.

Pitfalls: Attenzione alla differenza tra `map` e `flatMap`. Se avessimo usato `.map(riga -> Arrays.stream(riga.split("\\W+")))`, avremmo 
          ottenuto uno `Stream<Stream<String>>`, rendendo del tutto impossibile processare univocamente le singole stringhe nei successivi 
          filter e collect.
*/