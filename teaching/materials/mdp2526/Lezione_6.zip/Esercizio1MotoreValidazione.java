// Esercizio 1: Motore di Validazione
import java.util.ArrayList;
import java.util.List;

// Annotazione cruciale per imporre a livello di compilatore la presenza di un solo metodo astratto
@FunctionalInterface
interface Valutatore<T> {
    boolean esamina(T target); 
}

class Prodotto {
    private String nome;
    private double prezzo;
    private boolean disponibile;

    public Prodotto(String nome, double prezzo, boolean disponibile) {
        this.nome = nome;
        this.prezzo = prezzo;
        this.disponibile = disponibile;
    }

    public String getNome() { return nome; }
    public double getPrezzo() { return prezzo; }
    public boolean isDisponibile() { return disponibile; }

    // Metodo di utilità che verrà sfruttato tramite Method Reference nel test
    public boolean isEconomico() {
        return this.prezzo < 50.0;
    }

    @Override
    public String toString() {
        return nome + " (Prezzo: " + prezzo + "€, Disp: " + disponibile + ")";
    }
}

class FiltroDati {
    // Metodo generico statico: il parametro <T> assicura l'assoluto disaccoppiamento dal tipo (es. Prodotto)
    public static <T> List<T> applicaCriterio(List<T> elementi, Valutatore<T> criterio) {
        List<T> risultato = new ArrayList<>();
        for (T elemento : elementi) {
            // L'invocazione di esamina() trigghererà a runtime la logica della Lambda o del Method Reference
            if (criterio.esamina(elemento)) {
                risultato.add(elemento);
            }
        }
        return risultato;
    }
}

public class Esercizio1MotoreValidazione {
    public static void main(String[] args) {
        List<Prodotto> magazzino = List.of(
            new Prodotto("Laptop", 1200.0, true),
            new Prodotto("Mouse", 25.0, true),
            new Prodotto("Tastiera", 45.0, false),
            new Prodotto("Cavo HDMI", 15.0, true)
        );

        System.out.println("--- Test 1: Prodotti disponibili (Lambda Expression) ---");
        // La lambda (p) -> p.isDisponibile() fornisce l'implementazione concreta del metodo esamina
        List<Prodotto> disponibili = FiltroDati.applicaCriterio(magazzino, p -> p.isDisponibile());
        disponibili.forEach(System.out::println);

        System.out.println("\n--- Test 2: Prodotti disponibili E sotto 50€ (Lambda complessa) ---");
        List<Prodotto> economiciDisponibili = FiltroDati.applicaCriterio(magazzino, p -> p.isDisponibile() && p.getPrezzo() < 50.0);
        economiciDisponibili.forEach(System.out::println);

        System.out.println("\n--- Test 3: Prodotti economici (Method Reference) ---");
        // Method reference Class::method - Java inferisce l'istanza su cui chiamare il metodo (elemento)
        List<Prodotto> economici = FiltroDati.applicaCriterio(magazzino, Prodotto::isEconomico);
        economici.forEach(System.out::println);
    }
}

/*
💡 RIFLESSIONI DEL TUTOR

Decision Making: Ho strutturato il metodo `applicaCriterio` con polimorfismo parametrico `<T>`. Questo è il design corretto per rendere 
                 l'utilità completamente agnostica: oggi filtra un `Prodotto`, domani potrebbe filtrare un `Utente` o una `Stringa`.

Alternative: In un contesto reale di Java 8+, invece di definire una `FunctionalInterface` da zero, lo standard per test logici booleani 
             richiede l'uso di `java.util.function.Predicate<T>`. Offrirebbe inoltre metodi di default concatenabili come `.and()` e `.or()`.

Pitfalls: Tralasciare l'annotazione `@FunctionalInterface` non causa un errore immediato di sintassi, ma rimuove lo scudo del 
          compilatore. Se un altro sviluppatore aggiungesse un secondo metodo astratto all'interfaccia, tutte le lambda che la 
          implementano andrebbero irrimediabilmente in crash.

Focus: L'uso di `Prodotto::isEconomico` dimostra un Method Reference su un metodo di istanza associato a un tipo. Dal momento che 
       `applicaCriterio` lavora con uno stream di istanze, Java comprende automaticamente su quale instanza `p` mappare la chiamata 
       `p.isEconomico()`.
*/