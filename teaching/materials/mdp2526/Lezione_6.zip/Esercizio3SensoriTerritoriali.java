// Esercizio 3: Monitoraggio della Rete di Sensori Territoriali
import java.util.List;
import java.util.OptionalDouble;

class Misurazione {
    private double temperatura;
    private String timestamp;

    public Misurazione(double temperatura, String timestamp) {
        this.temperatura = temperatura;
        this.timestamp = timestamp;
    }

    public double getTemperatura() { return temperatura; }
    public String getTimestamp() { return timestamp; }
}

class SensoreMeteo {
    private String id;
    private List<Misurazione> storico;

    public SensoreMeteo(String id, List<Misurazione> storico) {
        this.id = id;
        this.storico = storico;
    }

    public String getId() { return id; }
    public List<Misurazione> getStorico() { return storico; }
}

class AreaGeografica {
    private List<SensoreMeteo> sensori;

    public AreaGeografica(List<SensoreMeteo> sensori) {
        this.sensori = sensori;
    }

    public OptionalDouble calcolaMediaAlteTemperature(double soglia) {
        return sensori.stream()
            // Da uno Stream<SensoreMeteo>, flatMap unisce tutte le collezioni interne "storico"
            // formando un unico enorme Stream<Misurazione> contenente i dati dell'intera area geografica
            .flatMap(sensore -> sensore.getStorico().stream())
            // mapToDouble sposta l'esecuzione dal paradigma orientato agli oggetti a quello primitivo (DoubleStream)
            // migliorando le performance e offrendo metodi matematici specializzati
            .mapToDouble(Misurazione::getTemperatura)
            // Trattiene solo i nodi (temperature primitive) il cui valore è strettamente superiore al limite
            .filter(temp -> temp > soglia)
            // average() computa la media artimetica; incapsula il risultato in OptionalDouble 
            // per far fronte all'evenienza in cui nessun dato superi il filtro
            .average();
    }
}

public class Esercizio3SensoriTerritoriali {
    public static void main(String[] args) {
        SensoreMeteo s1 = new SensoreMeteo("NODE-01", List.of(
            new Misurazione(15.5, "2026-05-21T08:00:00Z"),
            new Misurazione(28.0, "2026-05-21T12:00:00Z"),
            new Misurazione(30.5, "2026-05-21T14:00:00Z")
        ));

        SensoreMeteo s2 = new SensoreMeteo("NODE-02", List.of(
            new Misurazione(35.0, "2026-05-21T10:00:00Z"),
            new Misurazione(38.2, "2026-05-21T13:00:00Z"),
            new Misurazione(22.0, "2026-05-21T20:00:00Z")
        ));

        // Sensore edge-case: privo di rilevazioni atmosferiche
        SensoreMeteo s3 = new SensoreMeteo("NODE-FAILED", List.of()); 

        AreaGeografica area = new AreaGeografica(List.of(s1, s2, s3));

        System.out.println("--- Test 1: Calcolo Media Rilevazioni > 25.0°C ---");
        OptionalDouble mediaSuccesso = area.calcolaMediaAlteTemperature(25.0);
        // pattern di destrutturazione sicura tramite la classe Optional
        if (mediaSuccesso.isPresent()) {
            System.out.printf("Media calcolata: %.2f°C%n", mediaSuccesso.getAsDouble());
        }

        System.out.println("\n--- Test 2: Comportamento in assenza di dati (Soglia Inaccessibile) ---");
        OptionalDouble mediaAssente = area.calcolaMediaAlteTemperature(60.0);
        // Se si desidera far proseguire un calcolo di business algebrico, si inietta un valore predefinito di fallback
        double fallbackValue = mediaAssente.orElse(Double.NaN);
        System.out.println("Risultato rilevato o fallback iniettato: " + fallbackValue);
    }
}

/*
💡 RIFLESSIONI DEL TUTOR

Decision Making: Utilizzare `mapToDouble` è tassativo e superiore al normale `map`. Così facendo sfruttiamo uno stream specializzato 
                 per i valori primitivi (`DoubleStream`) neutralizzando gli effetti avversi sulla memoria portati dall'autoboxing 
                 (l'imballaggio continuo tra la primitiva `double` e la sua classe wrapper `Double`).

Alternative: Se l'esercizio avesse richiesto media, massimo, minimo e count contemporaneamente, avremmo rimpiazzato `.average()` con 
             `.summaryStatistics()`, ottenendo come ritorno l'oggetto onnicomprensivo `DoubleSummaryStatistics`.

Pitfalls: È severamente vietato dalla best practice concatenare ciecamente un `.getAsDouble()` subito dopo `.average()`. Come si nota 
          dal Test 2, se lo stream si "svuota" a causa del filtro impostato dalla soglia (o perché le liste native erano originariamente 
          vuote), quell'invocazione provocherebbe inesorabilmente un crash per `NoSuchElementException`.
*/