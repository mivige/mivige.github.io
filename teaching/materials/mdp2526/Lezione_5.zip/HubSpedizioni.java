// Esercizio 1: Pipeline di Tracciamento Spedizioni

import java.util.*;
import java.util.stream.Collectors;

/**
 * Enum che rappresenta lo stato logistico di un pacco.
 * Estesa per associare a ciascun valore un livello di priorità intero.
 */
enum StatoLogistico {
    IN_TRANSITO(2),
    CONSEGNATO(1),
    IN_PREPARAZIONE(3); // Aggiunto per arricchire lo scenario di test

    private final int priorita;

    StatoLogistico(int priorita) {
        this.priorita = priorita;
    }

    public int getPriorita() {
        return this.priorita;
    }
}

/**
 * Modello che rappresenta un singolo Pacco da tracciare.
 */
class Pacco {
    private final String id;
    private final double peso;
    private final String destinazione;
    private final StatoLogistico statoLogistico;

    public Pacco(String id, double peso, String destinazione, StatoLogistico statoLogistico) {
        this.id = id;
        this.peso = peso;
        this.destinazione = destinazione;
        this.statoLogistico = statoLogistico;
    }

    public String getId() { return id; }
    public double getPeso() { return peso; }
    public String getDestinazione() { return destinazione; }
    public StatoLogistico getStatoLogistico() { return statoLogistico; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Pacco pacco = (Pacco) o;
        return Objects.equals(id, pacco.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return String.format("Pacco{id='%s', peso=%.1f, stato=%s, dest='%s'}", 
                id, peso, statoLogistico, destinazione);
    }
}

/**
 * Gestore della collezione di pacchi e delle relative pipeline di Stream.
 */
public class HubSpedizioni {
    private final List<Pacco> pacchi = new ArrayList<>();

    public void aggiungiPacco(Pacco p) {
        pacchi.add(p);
    }

    /**
     * Seleziona i pacchi IN_TRANSITO, li ordina per peso decrescente,
     * estrae l'ID e accumula in un LinkedHashSet per preservare l'ordine ed evitare duplicati.
     */
    public LinkedHashSet<String> ottieniIdInTransitoOrdinati() {
        return pacchi.stream()
                // Filtra mantenendo solo i pacchi in transito
                .filter(p -> p.getStatoLogistico() == StatoLogistico.IN_TRANSITO)
                // Ordina in base al peso in modo decrescente invertendo il comparatore naturale
                .sorted(Comparator.comparingDouble(Pacco::getPeso).reversed())
                // Trasforma lo stream di Pacco in uno stream di String (ID)
                .map(Pacco::getId)
                // Raccoglie in un LinkedHashSet per garantire unicità e mantenere l'ordine del sorted()
                .collect(Collectors.toCollection(LinkedHashSet::new));
    }

    /**
     * Filtra i pacchi tramite un Predicate e li raggruppa in una mappa ordinata.
     * I pacchi in ogni gruppo sono ordinati per priorità dello stato logistico e poi per peso decrescente.
     */
    public Map<StatoLogistico, Set<Pacco>> raggruppaPacchiFiltrati(java.util.function.Predicate<Pacco> predicato) {
        // Definizione del comparatore composto richiesto dalle specifiche
        Comparator<Pacco> compPacco = Comparator
                // Ordina per priorità dello stato logistico (ordine naturale dell'intero)
                .comparingInt((Pacco p) -> p.getStatoLogistico().getPriorita())
                // In caso di parità di priorità, ordina per peso decrescente
                .thenComparing(Comparator.comparingDouble(Pacco::getPeso).reversed());

        return pacchi.stream()
                // Filtra i pacchi in base al predicato dinamico passato come parametro
                .filter(predicato)
                // Raggruppa i dati in una mappa dove la chiave è lo StatoLogistico
                .collect(Collectors.groupingBy(
                        Pacco::getStatoLogistico,
                        // Raccoglie gli elementi di ciascun gruppo in un TreeSet ordinato tramite il comparatore composto
                        Collectors.toCollection(() -> new TreeSet<>(compPacco))
                ));
    }

    public static void main(String[] args) {
        HubSpedizioni hub = new HubSpedizioni();
        
        // Configurazione dati di test (inclusi ID duplicati per verificare i vincoli dei Set)
        hub.aggiungiPacco(new Pacco("ZA111", 12.5, "Roma", StatoLogistico.IN_TRANSITO));
        hub.aggiungiPacco(new Pacco("ZA333", 45.0, "Milano", StatoLogistico.IN_TRANSITO));
        hub.aggiungiPacco(new Pacco("ZA222", 25.5, "Napoli", StatoLogistico.IN_TRANSITO));
        hub.aggiungiPacco(new Pacco("ZA111", 12.5, "Roma", StatoLogistico.IN_TRANSITO)); // Duplicato di ID
        hub.aggiungiPacco(new Pacco("ZA444", 8.0, "Torino", StatoLogistico.CONSEGNATO));
        hub.aggiungiPacco(new Pacco("ZA555", 50.0, "Firenze", StatoLogistico.IN_PREPARAZIONE));
        hub.aggiungiPacco(new Pacco("ZA666", 12.5, "Venezia", StatoLogistico.IN_TRANSITO)); // Stesso peso di ZA111

        System.out.println("========== TEST TASK 3: ID IN TRANSITO ORDINATI (PESO DECRESCENTE) ==========");
        LinkedHashSet<String> idOrdinati = hub.ottieniIdInTransitoOrdinati();
        // Ci si aspetta l'ordine degli ID associato ai pesi: 45.0 (ZA333), 25.5 (ZA222), 12.5 (ZA111), 12.5 (ZA666)
        // Il duplicato ZA111 inserito due volte deve comparire una sola volta.
        idOrdinati.forEach(id -> System.out.println("ID Pacco: " + id));

        System.out.println("\n========== TEST TASK 4: RAGGRUPPAMENTO AVANZATO CON PREDICATO (PESO > 10) ==========");
        // Predicato: seleziona solo i pacchi con peso strettamente superiore a 10.0 kg
        java.util.function.Predicate<Pacco> filtroPeso = p -> p.getPeso() > 10.0;
        
        Map<StatoLogistico, Set<Pacco>> mappaRaggruppata = hub.raggruppaPacchiFiltrati(filtroPeso);
        mappaRaggruppata.forEach((stato, setPacchi) -> {
            System.out.println("Stato: " + stato + " (Priorità: " + stato.getPriorita() + ")");
            setPacchi.forEach(p -> System.out.println("  -> " + p));
        });
    }
}

/*
 💡 RIFLESSIONI DEL TUTOR
 
 DECISION MAKING:
 1. Per il metodo 'ottieniIdInTransitoOrdinati', la scelta del 'LinkedHashSet' all'interno del collettore finale 
    è l'unico modo per ottemperare al duplice vincolo richiesto: eliminare i duplicati (proprietà del Set) 
    e preservare l'ordinamento decrescente stabilito dallo step intermedio '.sorted()' (proprietà della LinkedList).
 2. Nel metodo 'raggruppaPacchiFiltrati', per garantire che gli elementi interni a ciascun gruppo della mappa 
    fossero ordinati secondo il comparatore composto, si è scelto 'Collectors.toCollection(() -> new TreeSet<>(compPacco))'. 
    Un 'TreeSet' strutturato con un comparatore ad-hoc ordina i dati in tempo reale durante la fase di accumulazione.

 ALTERNATIVE:
 1. Nel primo esercizio, per eliminare i duplicati mantenendo l'ordine, avremmo potuto usare '.distinct()' nello stream 
    e poi raccogliere i dati in una comune 'List' tramite '.toList()'. Tuttavia, il vincolo esplicito della consegna 
    richiedeva l'uso di un 'LinkedHashSet'.
 2. Nel raggruppamento avanzato, avremmo potuto raccogliere in una lista semplice e poi invocare una successiva 
    operazione di rimodulazione o ordinamento sulle singole "value-lists" della mappa, ma l'utilizzo del downstream collector 
    'TreeSet' rende la pipeline atomica, elegante e performante.

 PITFALLS:
 1. L'errore più comune commesso dagli studenti consiste nell'utilizzare 'Collectors.toSet()' convinti che mantenga 
    l'ordine generato da '.sorted()'. In Java, 'Collectors.toSet()' istanzia generalmente un 'HashSet', il quale 
    disperde completamente l'ordine degli elementi a causa dell'hashing interno.
 2. Attenzione all'implementazione di 'equals' e 'hashCode' nella classe 'Pacco'. Se basati solo sull'attributo 'id', 
    due pacchi con stesso ID ma attributi diversi verranno considerati duplicati. Nel 'TreeSet' dell'esercizio 4, 
    inoltre, l'ordinamento è governato dal 'Comparator'; se il comparatore restituisce 0 per due pacchi diversi 
    (stessa priorità e stesso peso), il 'TreeSet' NON aggiungerà il secondo pacco perché lo considererà duplicato. 
    Per questo nel test sono stati usati ID unici per pesi identici, ed è fondamentale far capire agli studenti 
    che nei Set ordinati l'uguaglianza è dettata dal comparatore/compareTo e non da .equals().
*/