// Esercizio 2: Hub Logistico Multi-Corriere

import java.util.*;
import java.util.stream.Collectors;

/**
 * Enum che definisce le zone geografiche di copertura di un corriere.
 */
enum ZonaCopertura {
    NAZIONALE,
    INTERNAZIONALE,
    ZTL
}

/**
 * Rappresenta una singola Spedizione che contiene una lista di articoli.
 */
class Spedizione {
    private final List<String> articoli;

    public Spedizione(List<String> articoli) {
        // Evitiamo side-effect incapsulando la lista in una nuova istanza
        this.articoli = new ArrayList<>(articoli);
    }

    public List<String> getArticoli() {
        return Collections.unmodifiableList(articoli);
    }
}

/**
 * Rappresenta il Corriere operante in una specifica zona e provvisto delle sue spedizioni.
 */
class Corriere {
    private final String nome;
    private final List<Spedizione> spedizioni = new ArrayList<>();
    private final ZonaCopertura zonaCopertura;

    public Corriere(String nome, ZonaCopertura zonaCopertura) {
        this.nome = nome;
        this.zonaCopertura = zonaCopertura;
    }

    public String getNome() { return nome; }
    public ZonaCopertura getZonaCopertura() { return zonaCopertura; }
    public List<Spedizione> getSpedizioni() { return spedizioni; }

    public void aggiungiSpedizione(Spedizione s) {
        this.spedizioni.add(s);
    }
}

/**
 * Classe di coordinamento generale del network logistico.
 */
public class PiattaformaLogistica {
    private final List<Corriere> corrieri = new ArrayList<>();

    public void aggiungiCorriere(Corriere c) {
        this.corrieri.add(c);
    }

    /**
     * Estrae tutti gli articoli unici movimentati esclusivamente dai corrieri 
     * che rispondono al filtro basato sulla ZonaCopertura.
     * Sfrutta flatMap per linearizzare l'albero tridimensionale: Corriere -> Spedizione -> Articolo.
     */
    public Set<String> estraiTuttiArticoliUnici(java.util.function.Predicate<ZonaCopertura> filtroZona) {
        return corrieri.stream()
                // Step 1: Filtra i corrieri in base alla loro zona di copertura tramite il predicato
                .filter(corriere -> filtroZona.test(corriere.getZonaCopertura()))
                // Step 2: Primo flatMap per passare da Stream<Corriere> a Stream<Spedizione>
                .flatMap(corriere -> corriere.getSpedizioni().stream())
                // Step 3: Secondo flatMap per passare da Stream<Spedizione> a Stream<String> (articoli)
                .flatMap(spedizione -> spedizione.getArticoli().stream())
                // Step 4: Raccoglie in un Set per eliminare automaticamente ogni stringa duplicata
                .collect(Collectors.toSet());
    }

    public static void main(String[] args) {
        PiattaformaLogistica piattaforma = new PiattaformaLogistica();

        // Configurazione Corriere 1: NAZIONALE
        Corriere c1 = new Corriere("SDA_Naz", ZonaCopertura.NAZIONALE);
        c1.aggiungiSpedizione(new Spedizione(List.of("Smartphone", "Laptop", "Caricabatterie")));
        c1.aggiungiSpedizione(new Spedizione(List.of("Cuffie Bluetooth", "Laptop"))); // "Laptop" è duplicato interno

        // Configurazione Corriere 2: ZTL
        Corriere c2 = new Corriere("BiciExpress_ZTL", ZonaCopertura.ZTL);
        c2.aggiungiSpedizione(new Spedizione(List.of("Libro", "Smartphone"))); // "Smartphone" è duplicato inter-corriere
        c2.aggiungiSpedizione(new Spedizione(List.of("Caffè in grani")));

        // Configurazione Corriere 3: INTERNAZIONALE
        Corriere c3 = new Corriere("DHL_Int", ZonaCopertura.INTERNAZIONALE);
        c3.aggiungiSpedizione(new Spedizione(List.of("Fotocamera", "Obiettivo 50mm")));

        piattaforma.aggiungiCorriere(c1);
        piattaforma.aggiungiCorriere(c2);
        piattaforma.aggiungiCorriere(c3);

        System.out.println("========== TEST FLATMAP: ESTRAZIONE ARTICOLI SOLO DA NAZIONALE E ZTL ==========");
        // Predicato che accetta solo zone NAZIONALE oppure ZTL (escludendo INTERNAZIONALE)
        java.util.function.Predicate<ZonaCopertura> filtroNazEztl = zona -> 
                zona == ZonaCopertura.NAZIONALE || zona == ZonaCopertura.ZTL;

        Set<String> articoliEstratti = piattaforma.estraiTuttiArticoliUnici(filtroNazEztl);

        // Ci si aspetta la rimozione dei duplicati ("Laptop" e "Smartphone" devono apparire una volta sola)
        // L'articolo "Fotocamera" non deve apparire perché appartiene a un corriere INTERNAZIONALE.
        System.out.println("Numero di articoli unici estratti: " + articoliEstratti.size());
        articoliEstratti.forEach(articolo -> System.out.println(" - " + articolo));
    }
}

/*
 💡 RIFLESSIONI DEL TUTOR
 
 DECISION MAKING:
 1. Il problema richiede l'estrazione di elementi atomici situati in una gerarchia annidata a tre livelli 
    (Piattaforma -> Corriere -> Spedizione -> Articolo). L'uso di 'flatMap' è la scelta ottimale 
    poiché "spiana" (flatten) le collezioni intermedie convertendole in flussi continui dello stream principale.
 2. Per il tipo di ritorno è stato scelto 'Collectors.toSet()' che istanzia internamente un 'HashSet'. 
    Dal momento che la specifica richiede la rimozione dei duplicati senza imporre un ordinamento alfabetico 
    o di inserimento, l'HashSet offre le performance migliori (O(1) amortizzato per l'inserimento).

 ALTERNATIVE:
 1. Senza l'ausilio di 'flatMap', l'algoritmo avrebbe richiesto una sequenza complessa e scarsamente leggibile 
    di cicli 'for' annidati:
    for(Corriere c : corrieri) {
        if(filtro.test(c.getZonaCopertura())) {
            for(Spedizione s : c.getSpedizioni()) {
                for(String art : s.getArticoli()) { set.add(art); }
            }
        }
    }
    L'approccio funzionale riduce il codice boilerplate e minimizza la possibilità di introdurre bug di indicizzazione.

 PITFALLS:
 1. Confondere 'map' con 'flatMap': se avessimo usato '.map(Corriere::getSpedizioni)', avremmo ottenuto uno 
    'Stream<List<Spedizione>>'. Successivamente, applicando un altro 'map' per gli articoli, il tipo risultante 
    sarebbe diventato una struttura ingestibile di stream annidati ('Stream<Stream<List<String>>>'). 
    Bisogna instillare la regola d'oro: "Se la funzione di mapping restituisce una collezione o uno stream, 
    e si vuole manipolare l'elemento base, si usa flatMap".
 2. Passaggio del predicato errato: la traccia richiede un predicato basato su 'ZonaCopertura', ma viene applicato 
    durante lo stream di oggetti 'Corriere'. Gli studenti tendono a sbagliare la firma del metodo accettando 
    'Predicate<Corriere>' anziché 'Predicate<ZonaCopertura>'. L'estrazione pulita si ottiene invocando 
    'filtroZona.test(corriere.getZonaCopertura())'.
*/