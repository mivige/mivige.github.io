// ==========================================
// ESERCIZIO 2: Raccolta di Canzoni
// ==========================================

import java.util.HashSet;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;
import java.util.Comparator;
import java.util.stream.Collectors;

// Si definisca una classe Canzone i cui oggetti sono costruiti con nome, autore .
class Canzone implements Comparable<Canzone> {
    private String nome;
    private String autore;
    private int durataSecondi;

    public Canzone(String nome, String autore, int durataSecondi) {
        this.nome = nome;
        this.autore = autore;
        this.durataSecondi = durataSecondi;
    }

    public String getNome() { return nome; }
    public String getAutore() { return autore; }
    public int getDurataSecondi() { return durataSecondi; }

    // Evita duplicati di canzoni uguali per nome e autore.
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Canzone canzone = (Canzone) o;
        return Objects.equals(nome, canzone.nome) && Objects.equals(autore, canzone.autore);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nome, autore);
    }

    // Rappresentazione sotto forma di stringa.
    @Override
    public String toString() {
        return nome + " - " + autore + " (" + durataSecondi + "s)";
    }

    // Ordine naturale basato su nome e successivamente autore.
    @Override
    public int compareTo(Canzone other) {
        int nameCompare = this.nome.compareTo(other.nome);
        if (nameCompare != 0) {
            return nameCompare;
        }
        return this.autore.compareTo(other.autore);
    }
}

// Classe Raccolta con HashSet.
class Raccolta {
    protected Set<Canzone> canzoni;

    public Raccolta() {
        this.canzoni = new HashSet<>();
    }

    public void aggiungiCanzone(Canzone c) {
        canzoni.add(c);
    }

    public Set<Canzone> getCanzoni() {
        return canzoni;
    }

    @Override
    public String toString() {
        return "Raccolta: " + canzoni.toString();
    }
}

// Sottoclasse RaccoltaOrdinata con TreeSet.
class RaccoltaOrdinata extends Raccolta {
    public RaccoltaOrdinata() {
        // Il TreeSet usa automaticamente il compareTo implementato nell'interfaccia Comparable di Canzone.
        this.canzoni = new TreeSet<>(); 
    }
}

public class Esercizio2_Canzoni {
    public static void main(String[] args) {
        System.out.println("--- ESERCIZIO 2: CANZONI ---");

        RaccoltaOrdinata raccolta = new RaccoltaOrdinata();
        raccolta.aggiungiCanzone(new Canzone("Bohemian Rhapsody", "Queen", 354));
        raccolta.aggiungiCanzone(new Canzone("Stairway to Heaven", "Led Zeppelin", 482));
        raccolta.aggiungiCanzone(new Canzone("Hotel California", "Eagles", 390));
        // Test di inserimento duplicato (stesso nome e autore)
        raccolta.aggiungiCanzone(new Canzone("Hotel California", "Eagles", 400)); 

        System.out.println(raccolta);

        // 1. Calcolare la durata totale utilizzando mapToInt e sum.
        // mapToInt converte lo Stream<Canzone> in un IntStream, ottimizzato per primitive.
        int durataTotale = raccolta.getCanzoni().stream()
                .mapToInt(Canzone::getDurataSecondi)
                .sum();
        System.out.println("Durata totale (secondi): " + durataTotale);

        // 2. Restituire la canzone con la durata massima utilizzando max e un Comparator.
        // Il risultato è un Optional per proteggerci dal caso in cui la collezione sia vuota.
        Optional<Canzone> canzonePiuLunga = raccolta.getCanzoni().stream()
                .max(Comparator.comparingInt(Canzone::getDurataSecondi));
        
        // Uso di ifPresent per gestire l'Optional in modo sicuro.
        canzonePiuLunga.ifPresent(c -> System.out.println("Canzone più lunga: " + c));

        // 3. Creare una stringa con tutti i titoli separati da virgola utilizzando Collectors.joining(", ").
        String titoli = raccolta.getCanzoni().stream()
                .map(Canzone::getNome)
                .collect(Collectors.joining(", "));
        System.out.println("Titoli delle canzoni: " + titoli);
    }
}

/* 💡 RIFLESSIONI DEL TUTOR
 *  Decision Making: Per mantenere un ordine sulle canzoni basato sul nome e sull'autore, ho implementato l'interfaccia `<T extends Comparable<T>>` 
 *                   direttamente sulla classe `Canzone`. In questo modo, l'istanziazione di un `TreeSet` non necessita del passaggio di un custom 
 *                   Comparator al costruttore, rendendo l'uso della `RaccoltaOrdinata` molto trasparente.
 * 
 *  Alternative: Avrei potuto evitare di far implementare `Comparable` a `Canzone` passando una lambda al costruttore del `TreeSet`: 
 *               `new TreeSet<>(Comparator.comparing(Canzone::getNome).thenComparing(Canzone::getAutore))`.
 *  
 *  Pitfalls (Trappole): Un errore critico in questo esercizio è implementare `equals` e `hashCode` senza considerare tutte e sole le variabili 
 *                       chiave (nome e autore). Se si include anche la durata, due canzoni con lo stesso nome e autore ma durate diverse 
 *                       verrebbero considerate distinte, vanificando l'obiettivo di evitare duplicati.
 * 
 *  Focus: `Optional<T>` è un pattern essenziale. Il metodo `max()` ritorna `Optional` perché, formalmente, lo Stream potrebbe derivare da una 
 *         collezione vuota.
 */