// ==========================================
// ESERCIZIO 3: Prodotti e Raggruppamenti
// ==========================================

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

// Definizione della classe Prodotto con campi nome, categoria e prezzo.
class Prodotto {
    private String nome;
    private String categoria;
    private double prezzo;

    public Prodotto(String nome, String categoria, double prezzo) {
        this.nome = nome;
        this.categoria = categoria;
        this.prezzo = prezzo;
    }

    public String getNome() { return nome; }
    public String getCategoria() { return categoria; }
    public double getPrezzo() { return prezzo; }

    @Override
    public String toString() {
        return nome + " (E " + prezzo + ")";
    }
}

public class Esercizio3_Prodotti {
    public static void main(String[] args) {
        System.out.println("--- ESERCIZIO 3: PRODOTTI E PARTIZIONAMENTI ---");

        List<Prodotto> magazzino = Arrays.asList(
            new Prodotto("Laptop", "Elettronica", 1200.00),
            new Prodotto("Mouse", "Elettronica", 25.50),
            new Prodotto("Tastiera", "Elettronica", 45.00),
            new Prodotto("Sedia", "Arredamento", 150.00),
            new Prodotto("Scrivania", "Arredamento", 250.00),
            new Prodotto("Penna", "Cancelleria", 2.50)
        );

        // 1. Map dove la chiave è la categoria e il valore è la lista dei prodotti.
        // Collectors.groupingBy raggruppa gli elementi in base a una funzione di classificazione (in questo caso il getter della categoria).
        Map<String, List<Prodotto>> perCategoria = magazzino.stream()
                .collect(Collectors.groupingBy(Prodotto::getCategoria));
        System.out.println("Raggruppati per categoria:\n" + perCategoria);

        // 2. Dividere i prodotti in due gruppi: prezzo superiore a 50€ (true) e inferiore o uguale (false).
        // partitioningBy accetta un Predicate e ritorna SEMPRE una mappa con chiavi Boolean (true/false).
        Map<Boolean, List<Prodotto>> partizionatiPerPrezzo = magazzino.stream()
                .collect(Collectors.partitioningBy(p -> p.getPrezzo() > 50.0));
        System.out.println("\nProdotti con prezzo > 50 E: " + partizionatiPerPrezzo.get(true));
        System.out.println("Prodotti con prezzo <= 50 E: " + partizionatiPerPrezzo.get(false));

        // 3. Per ogni categoria, calcolare il prezzo medio dei prodotti utilizzando Collectors.averagingDouble.
        // Qui groupingBy utilizza un "downstream collector" per applicare un'ulteriore operazione ai valori raggruppati.
        Map<String, Double> prezzoMedioPerCategoria = magazzino.stream()
                .collect(Collectors.groupingBy(
                        Prodotto::getCategoria, 
                        Collectors.averagingDouble(Prodotto::getPrezzo)
                ));
        System.out.println("\nPrezzo medio per categoria:\n" + prezzoMedioPerCategoria);
    }
}

/* 💡 RIFLESSIONI DEL TUTOR
 *  
 *  Decision Making: L'utilizzo di `Collectors.partitioningBy` al posto di un `groupingBy(p -> p.getPrezzo() > 50)` è la scelta corretta 
 *                   per separare un dataset in due sottoinsiemi definiti da una logica vero/falso. A differenza di `groupingBy`, 
 *                   garantisce sempre la presenza delle chiavi `Boolean.TRUE` e `Boolean.FALSE` nella Mappa risultante, evitando `NullPointerException`.
 * 
 *  Alternative: Si potevano eseguire due stream separati con due `.filter()`, uno in negazione dell'altro. Questo approccio è scorretto a livello di 
 *               performance in quanto itera i dati due volte, infrangendo il principio di singola elaborazione della pipeline.
 * 
 *  Pitfalls (Trappole): Molti studenti si spaventano di fronte ai "downstream collectors", ma in realtà sono un potente strumento di composizione. 
 *                       Non è raro vedere errori di sintassi o di logica quando si tenta di annidare più operazioni all'interno di un `groupingBy`.
 * 
 *  Focus: Si noti l'utilizzo della composizione delle funzioni nel groupingBy al punto 3.
 */