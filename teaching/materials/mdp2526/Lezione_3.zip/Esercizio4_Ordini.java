// ==========================================
// ESERCIZIO 4: Pipeline Complesse - Ordini
// ==========================================

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

// Utilizziamo una versione di Prodotto adattata con equals e hashCode per permettere il distinct().
class ProdottoOrdine {
    private String nome;
    private double prezzo;

    public ProdottoOrdine(String nome, double prezzo) {
        this.nome = nome;
        this.prezzo = prezzo;
    }

    public String getNome() { return nome; }
    public double getPrezzo() { return prezzo; }

    // Implementiamo equals e hashCode per far funzionare correttamente distinct() sui prodotti duplicati.
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ProdottoOrdine that = (ProdottoOrdine) o;
        return Double.compare(that.prezzo, prezzo) == 0 && Objects.equals(nome, that.nome);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nome, prezzo);
    }

    @Override
    public String toString() { return nome + " (E " + prezzo + ")"; }
}

// Definizione classe Ordine.
class Ordine {
    private List<ProdottoOrdine> prodotti;
    private LocalDate dataAcquisto;

    public Ordine(List<ProdottoOrdine> prodotti, LocalDate dataAcquisto) {
        this.prodotti = prodotti;
        this.dataAcquisto = dataAcquisto;
    }

    public List<ProdottoOrdine> getProdotti() { return prodotti; }
    public LocalDate getDataAcquisto() { return dataAcquisto; }
}

public class Esercizio4_Ordini {
    public static void main(String[] args) {
        System.out.println("--- ESERCIZIO 4: PIPELINE COMPLESSE ---");

        List<Ordine> ordini = Arrays.asList(
            new Ordine(Arrays.asList(
                new ProdottoOrdine("Laptop", 1200.0), 
                new ProdottoOrdine("Mouse", 25.0)), 
                LocalDate.of(2025, 3, 10)),
            new Ordine(Arrays.asList(
                new ProdottoOrdine("Tastiera", 45.0), 
                new ProdottoOrdine("Monitor", 300.0), 
                new ProdottoOrdine("Mouse", 25.0)), // Duplicato
                LocalDate.of(2025, 5, 20)),
            new Ordine(Arrays.asList(
                new ProdottoOrdine("Stampante", 150.0)), 
                LocalDate.of(2026, 1, 15)) // Fuori dal 2025
        );

        // 1. Ottenere uno stream globale di singoli prodotti con flatMap.
        // flatMap "appiattisce" Stream<List<ProdottoOrdine>> in Stream<ProdottoOrdine>.
        // 2. Filtrare duplicati e restituire lista di nomi ordinata per prezzo decrescente.
        List<String> nomiProdottiUnici = ordini.stream()
                // Estrae lo stream di prodotti da ogni singolo ordine.
                .flatMap(ordine -> ordine.getProdotti().stream()) 
                // Elimina i duplicati (necessita che equals e hashCode siano implementati in ProdottoOrdine).
                .distinct() 
                // Ordina in base al prezzo in maniera decrescente.
                .sorted(Comparator.comparingDouble(ProdottoOrdine::getPrezzo).reversed()) 
                // Mappa l'oggetto complesso nel solo campo nome.
                .map(ProdottoOrdine::getNome) 
                // Operazione terminale necessaria per creare la nuova lista.
                .collect(Collectors.toList());

        System.out.println("Nomi dei prodotti unici (prezzo decrescente):\n" + nomiProdottiUnici);

        // 3. Trovare il prodotto più costoso mai acquistato nel 2025.
        Optional<ProdottoOrdine> prodottoPiuCostoso2025 = ordini.stream()
                // Filtra solo gli ordini di quell'anno.
                .filter(o -> o.getDataAcquisto().getYear() == 2025) 
                // Appiattisce i prodotti.
                .flatMap(o -> o.getProdotti().stream()) 
                // Trova il massimo usando un Comparator basato sul prezzo.
                .max(Comparator.comparingDouble(ProdottoOrdine::getPrezzo));

        prodottoPiuCostoso2025.ifPresent(p -> 
            System.out.println("\nProdotto più costoso del 2025: " + p)
        );
    }
}

/* 💡 RIFLESSIONI DEL TUTOR
 * 
 *  Decision Making: L'utilizzo di `flatMap` è lo snodo vitale di questo esercizio. Senza di esso, manipoleremmo uno `Stream<List<ProdottoOrdine>>`, 
 *                   rendendo quasi impossibile il sort o il distinct sui singoli elementi. Il `flatMap` distrugge le "scatole" (le Liste dentro 
 *                   gli Ordini) riversandone il contenuto su un unico nastro trasportatore.
 * 
 *  Pitfalls (Trappole): L'errore che commettono molti è applicare `distinct()` su un oggetto personalizzato senza aver fatto l'Override di 
 *                       `equals()` e `hashCode()`. Senza questo accorgimento, Java usa l'identità di memoria (il riferimento in RAM), e oggetti 
 *                       semanticamente uguali (es. due "Mouse" da 25€) verrebbero considerati diversi e non filtrati.
 * 
 *  Focus: Notare bene che la chiamata a `sorted()` o `filter()` non va ad alterare l'ordinamento o le posizioni della `List<Ordine>` di partenza, 
 *         in quanto gli stream sono strutturalmente immutabili rispetto alla sorgente e non creano side-effects collaterali.
 */