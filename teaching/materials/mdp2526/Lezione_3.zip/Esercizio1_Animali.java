// ==========================================
// ESERCIZIO 1: Analisi Funzionale di Animali
// ==========================================

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

// Progettazione della gerarchia della classe Animale.
abstract class Animale {
    private String nome;

    public Animale(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }

    // Metodi di default per le caratteristiche. Le sottoclassi faranno l'override se necessario.
    public boolean puoVolare() { return false; }
    public boolean puoNuotare() { return false; }
    public boolean isDomestico() { return false; }
}

// Implementazione delle specifiche classi di animali con le relative caratteristiche.
class Uccello extends Animale {
    public Uccello(String nome) { super(nome); }
    @Override public boolean puoVolare() { return true; }
}

class Pinguino extends Uccello {
    public Pinguino(String nome) { super(nome); }
    @Override public boolean puoVolare() { return false; } // I pinguini non volano
    @Override public boolean puoNuotare() { return true; }
}

class Aquila extends Uccello {
    public Aquila(String nome) { super(nome); }
    @Override public boolean puoVolare() { return true; }
}

class Pesce extends Animale {
    public Pesce(String nome) { super(nome); }
    @Override public boolean puoNuotare() { return true; }
}

class Cane extends Animale {
    public Cane(String nome) { super(nome); }
    @Override public boolean isDomestico() { return true; }
}

class Gatto extends Animale {
    public Gatto(String nome) { super(nome); }
    @Override public boolean isDomestico() { return true; }
}

public class Esercizio1_Animali {
    public static void main(String[] args) {
        // Creazione di una lista di oggetti di tipo Animale.
        List<Animale> animali = Arrays.asList(
            new Cane("Fido"),
            new Gatto("Silvestro"),
            new Pesce("Nemo"),
            new Aquila("Re delle Montagne"),
            new Uccello("Titti"),
            new Pinguino("Kowalski")
        );

        System.out.println("--- ESERCIZIO 1: ANIMALI ---");

        // 1. Restituire una lista contenente solo i nomi degli animali domestici.
        // Utilizziamo un method reference (Animale::isDomestico) come Predicate per il filter.
        // Utilizziamo un method reference (Animale::getNome) come Function per estrarre la stringa.
        List<String> nomiDomestici = animali.stream()
                .filter(Animale::isDomestico) 
                .map(Animale::getNome)        
                .collect(Collectors.toList());
        System.out.println("Animali domestici: " + nomiDomestici);

        // 2. Filtrare gli animali in grado di volare, stamparne il nome in maiuscolo e ordinare alfabeticamente.
        System.out.print("Animali volanti (ordinati e maiuscolo): ");
        animali.stream()
                .filter(Animale::puoVolare)
                // Trasformiamo il nome in maiuscolo tramite una lambda expression
                .map(a -> a.getNome().toUpperCase()) 
                // Ordina le stringhe secondo l'ordinamento naturale (alfabetico)
                .sorted() 
                // Operazione terminale per stampare ogni elemento.
                .forEach(nome -> System.out.print(nome + ", ")); 
        System.out.println();

        // 3. Calcolare il numero totale di animali che possiedono la capacità di nuotare.
        // L'operazione terminale count() restituisce un long.
        long nuotatori = animali.stream()
                .filter(Animale::puoNuotare)
                .count();
        System.out.println("Numero totale di animali che sanno nuotare: " + nuotatori);
    }
}

/* 💡 RIFLESSIONI DEL TUTOR
 * 
 *  Decision Making: Ho preferito modellare le "caratteristiche" (volare, nuotare, ecc.) come metodi booleani direttamente nella classe astratta `Animale` che ritornano `false` di default. 
 *                   Questo evita il ricorso a complessi check basati su `instanceof` e il partizionamento tramite interfacce (es. `Volante`, `Nuotatore`), che avrebbero reso le pipeline 
 *                   degli Stream molto meno pulite e piene di cast.
 *  
 *  Alternative: Un'alternativa elegante sarebbe stata utilizzare un costrutto basato su Interfacce (es. `implements Nuotatore`) e poi usare `filter(a -> a instanceof Nuotatore)`. 
 *               Tuttavia, in ottica di dimostrare i method references (`Animale::puoNuotare` ), l'approccio scelto risulta sintatticamente più idiomatico.
 *  
 *  Pitfalls (Trappole): Lo stream va rigenerato dalla sorgente se si vuole fare una nuova elaborazione. Uno stream non può essere riutilizzato una volta consumato.
 *  
 *  Focus: L'uso di `map(a -> a.getNome().toUpperCase())` cambia il tipo generico dello stream da `Stream<Animale>` a `Stream<String>`, dimostrando la natura trasformativa del costrutto `map`.
 */