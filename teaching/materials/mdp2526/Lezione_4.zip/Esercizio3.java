// Esercizio 3 - Monitoraggio E-commerce: Raggruppamento 

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

enum StatoOrdine { SPEDITO, IN_ATTESA, ANNULLATO } 

// 1. Definizione classe Ordine 
class Ordine {
    private String idOrdine;
    private String cliente;
    private double importo;
    private StatoOrdine stato;

    public Ordine(String idOrdine, String cliente, double importo, StatoOrdine stato) {
        this.idOrdine = idOrdine;
        this.cliente = cliente;
        this.importo = importo;
        this.stato = stato;
    }

    public double getImporto() { return importo; }
    public StatoOrdine getStato() { return stato; }

    @Override
    public String toString() { return "Ord{" + idOrdine + ", €" + importo + "}"; }
}

public class Esercizio3 {
    public static void main(String[] args) {
        List<Ordine> ordini = Arrays.asList(
                new Ordine("O1", "Alice", 150.0, StatoOrdine.SPEDITO),
                new Ordine("O2", "Bob", 600.0, StatoOrdine.SPEDITO),
                new Ordine("O3", "Charlie", 450.0, StatoOrdine.IN_ATTESA),
                new Ordine("O4", "Dave", 800.0, StatoOrdine.IN_ATTESA),
                new Ordine("O5", "Eve", 50.0, StatoOrdine.ANNULLATO)
        );

        System.out.println("--- TEST E-COMMERCE ---");

        // 2 & 3. Raggruppare per stato e sommare gli importi usando downstream collector 
        // Collectors.groupingBy accetta una funzione di classificazione (la chiave) e un Collector secondario (per il valore)
        Map<StatoOrdine, Double> sommaPerStato = ordini.stream()
                .collect(Collectors.groupingBy(
                        Ordine::getStato,
                        Collectors.summingDouble(Ordine::getImporto) // Downstream collector che accumula le somme
                ));

        System.out.println("Somma importi per stato:");
        sommaPerStato.forEach((stato, somma) -> System.out.println(stato + ": €" + somma));

        // 4. Partizionare gli ordini in "Premium" (> 500) e "Standard" 
        // partitioningBy garantisce sempre una mappa con due sole chiavi: true e false.
        Map<Boolean, List<Ordine>> ordiniPartizionati = ordini.stream()
                .collect(Collectors.partitioningBy(
                        o -> o.getImporto() > 500.0 // True = Premium, False = Standard
                ));

        System.out.println("\nOrdini Premium (> 500€): " + ordiniPartizionati.get(true));
        System.out.println("Ordini Standard (<= 500€): " + ordiniPartizionati.get(false));
    }
}

/* 💡 RIFLESSIONI DEL TUTOR
 * Decision Making: Ho utilizzato `Collectors.partitioningBy` per il secondo requisito in quanto il partizionamento è 
 *                  ottimizzato internamente in Java per scenari booleani, rispetto a un generico `groupingBy` basato su boolean.
 * 
 * Alternative: Invece di `summingDouble`, si poteva usare `reducing(0.0, Ordine::getImporto, Double::sum)`, 
 *              ma `summingDouble` è semanticamente più chiaro per chi legge il codice.
 * 
 * Pitfalls (Trappole): Dimenticarsi il "downstream collector" in `groupingBy` fa sì che il risultato sia una mappa 
 *                      `Map<StatoOrdine, List<Ordine>>`, che non risponde al quesito di trovare la somma totale. È fondamentale passare la funzione di aggregazione.
 * 
 * Focus: L'ecosistema dei `Collectors` di Java permette la composizione: un raccoglitore può delegare a un altro (downstream) l'elaborazione dei raggruppamenti logici.
 */