// Esercizio 2 - Sistema Universitario 

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

// 1. Definisci Studente e Corso 
class Studente {
    private String nome;
    private String matricola;

    public Studente(String nome, String matricola) {
        this.nome = nome;
        this.matricola = matricola;
    }

    public String getNome() { return nome; }
    public String getMatricola() { return matricola; }

    // Rimuovere i duplicati basandosi sulla matricola 
    // È essenziale fare l'override di equals e hashCode per far funzionare correttamente distinct()
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Studente studente = (Studente) o;
        return Objects.equals(matricola, studente.matricola);
    }

    @Override
    public int hashCode() {
        return Objects.hash(matricola);
    }

    @Override
    public String toString() { return nome + " (" + matricola + ")"; }
}

class Corso {
    private String nomeCorso;
    private List<Studente> listaIscritti;

    public Corso(String nomeCorso, List<Studente> listaIscritti) {
        this.nomeCorso = nomeCorso;
        this.listaIscritti = listaIscritti;
    }

    public List<Studente> getListaIscritti() { return listaIscritti; }
}

public class Esercizio2 {
    public static void main(String[] args) {
        Studente s1 = new Studente("Mario Rossi", "MAT001");
        Studente s2 = new Studente("Giulia Bianchi", "MAT002");
        Studente s3 = new Studente("Alessandro Del Piero", "MAT003");
        
        // Studente duplicato per testare la rimozione (stessa matricola di s1)
        Studente s4 = new Studente("Mario Rossi", "MAT001"); 

        Corso c1 = new Corso("Java Base", Arrays.asList(s1, s2));
        Corso c2 = new Corso("Database", Arrays.asList(s2, s3, s4));

        List<Corso> universita = Arrays.asList(c1, c2);

        System.out.println("--- TEST SISTEMA UNIVERSITARIO ---");

        // 2, 3, 4. Utilizzare flatMap per appiattire la gerarchia, rimuovere duplicati e restituire lista di nomi decrescente per lunghezza 
        List<String> nomiStudentiOrdinati = universita.stream()
                // map restituisce Stream<List<Studente>>, flatMap appiattisce in Stream<Studente> 
                .flatMap(corso -> corso.getListaIscritti().stream()) 
                .distinct() // Funziona correttamente grazie all'override di equals e hashCode in Studente 
                .map(Studente::getNome) // Trasforma lo Stream<Studente> in Stream<String> 
                // Comparator.comparingInt valuta la lunghezza della stringa. reversed() inverte l'ordine.
                .sorted(Comparator.comparingInt(String::length).reversed()) 
                .collect(Collectors.toList());

        System.out.println("Studenti unici (ordinati per lunghezza nome desc):");
        nomiStudentiOrdinati.forEach(System.out::println);
    }
}

/* 💡 RIFLESSIONI DEL TUTOR
 * Decision Making: Ho implementato `equals` e `hashCode` unicamente sulla proprietà `matricola` della classe `Studente`.
 *                  Questo permette all'operatore `.distinct()` dello stream di identificare univocamente l'identità dello studente, indipendentemente dal corso.
 * 
 * Alternative: Se non fosse possibile modificare la classe `Studente` (es. classe di una libreria di terze parti), 
 *              avremmo potuto evitare i duplicati usando `Collectors.toMap(Studente::getMatricola, s -> s, (s1, s2) -> s1)` o simili, ma `distinct()` è nettamente più leggibile.
 * 
 * Pitfalls (Trappole): Usare `.map()` al posto di `.flatMap()` avrebbe creato uno `Stream<List<Studente>>` impossibile da manipolare singolarmente in modo diretto. 
 *                      Inoltre, dimenticare l'override di `equals/hashCode` farebbe fallire la regola dei duplicati perché l'uguaglianza di default si baserebbe sui riferimenti in memoria.
 * 
 * Focus: `flatMap` è lo strumento di eccellenza per le relazioni 1-a-N, espandendo i contenitori interni in un flusso unico.
 */