// Esercizio 1 - Analisi Performance Flotta Veicoli

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

// 1. Si crei una classe Veicolo con campi targa, modello, chilometriPercorsi (double) e livelloCarburante (int da 0 a 100). 
class Veicolo {
    private String targa;
    private String modello;
    private double chilometriPercorsi;
    private int livelloCarburante;

    public Veicolo(String targa, String modello, double chilometriPercorsi, int livelloCarburante) {
        this.targa = targa;
        this.modello = modello;
        this.chilometriPercorsi = chilometriPercorsi;
        this.livelloCarburante = livelloCarburante;
    }

    public String getTarga() { return targa; }
    public String getModello() { return modello; }
    public double getChilometriPercorsi() { return chilometriPercorsi; }
    public int getLivelloCarburante() { return livelloCarburante; }

    @Override
    public String toString() {
        return "Veicolo{" + "targa='" + targa + '\'' + ", km=" + chilometriPercorsi + ", carburante=" + livelloCarburante + "%}";
    }
}

public class Esercizio1 {
    public static void main(String[] args) {
        // Creazione flotta di test
        List<Veicolo> flotta = Arrays.asList(
                new Veicolo("AB123CD", "Fiat Panda", 45000.5, 50),
                new Veicolo("EF456GH", "Ford Fiesta", 120500.0, 15),
                new Veicolo("IL789MN", "Volkswagen Golf", 85000.0, 80),
                new Veicolo("OP012QR", "Toyota Yaris", 15000.0, 10)
        );

        System.out.println("--- TEST FLOTTA VEICOLI ---");

        // 2. Media chilometri percorsi da veicoli con livello carburante > 20 
        // Utilizzo mapToDouble per evitare l'overhead dell'autoboxing e ottenere un DoubleStream 
        double mediaKm = flotta.stream()
                .filter(v -> v.getLivelloCarburante() > 20) // Predicato: solo carburante > 20%
                .mapToDouble(Veicolo::getChilometriPercorsi) // Estrae il dato numerico primitivo double
                .average() // Restituisce un OptionalDouble 
                .orElse(0.0); // Gestisce il caso di stream vuoto fornendo un fallback 
        
        System.out.println("Media KM (carburante > 20%): " + mediaKm);

        // 3. Veicolo con maggior numero di chilometri usando max con un Comparator 
        // max() richiede un Comparator. comparingDouble è ottimizzato per i primitivi double.
        Optional<Veicolo> maxKmVeicolo = flotta.stream()
                .max(Comparator.comparingDouble(Veicolo::getChilometriPercorsi));
        
        maxKmVeicolo.ifPresent(v -> System.out.println("Veicolo con più KM: " + v.getTarga() + " (" + v.getChilometriPercorsi() + " km)"));

        // 4. Verificare se esiste almeno un veicolo con più di 100.000 km usando anyMatch 
        // anyMatch è un'operazione terminale di "short-circuiting", si ferma appena trova il primo match.
        boolean over100k = flotta.stream()
                .anyMatch(v -> v.getChilometriPercorsi() > 100000.0);
        
        System.out.println("Esiste almeno un veicolo oltre i 100.000 km? " + over100k);
    }
}

/* 💡 RIFLESSIONI DEL TUTOR
 * Decision Making: Ho utilizzato `mapToDouble` invece di `map` normale per sfruttare `DoubleStream`, 
 *                  che offre metodi statistici diretti come `average()` senza pesare sul Garbage Collector con l'autoboxing dei Double.
 * 
 * Alternative: Per calcolare il veicolo con più km, si poteva anche ordinare in senso decrescente e prendere il `findFirst()`,
 *              ma l'uso di `max(Comparator)` è computazionalmente più leggero (O(n) contro O(n log n) dell'ordinamento).
 * 
 * Pitfalls (Trappole): L'errore più comune qui è chiamare `.getAsDouble()` direttamente su `average()` senza 
 *                      verificare se il valore è presente, causando un'eccezione a runtime se la lista originaria fosse vuota o il filtro escludesse tutti gli elementi. 
 *                      L'uso di `orElse(0.0)` o `ifPresent` è imperativo.
 * 
 * Focus: L'uso corretto di `OptionalDouble` per i tipi primitivi differisce dal generico `Optional<T>`.
 */