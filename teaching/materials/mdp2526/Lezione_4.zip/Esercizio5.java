// Esercizio 5 - Analisi Log Server Multi-Livello 

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

enum LivelloLog { INFO, ERROR, DEBUG } 

// 1. Classe LogEntry 
class LogEntry {
    private LocalDateTime timestamp;
    private LivelloLog livello;
    private String messaggio;
    private String servizioSorgente;

    public LogEntry(LocalDateTime timestamp, LivelloLog livello, String messaggio, String servizioSorgente) {
        this.timestamp = timestamp;
        this.livello = livello;
        this.messaggio = messaggio;
        this.servizioSorgente = servizioSorgente;
    }

    public LocalDateTime getTimestamp() { return timestamp; }
    public LivelloLog getLivello() { return livello; }
    public String getMessaggio() { return messaggio; }
    public String getServizioSorgente() { return servizioSorgente; }
}

public class Esercizio5 {
    public static void main(String[] args) {
        LocalDateTime now = LocalDateTime.now();
        List<LogEntry> logs = Arrays.asList(
                new LogEntry(now.minusMinutes(10), LivelloLog.ERROR, "NullPointerException", "PaymentService"),
                new LogEntry(now.minusMinutes(5), LivelloLog.DEBUG, "Tracing connection...", "PaymentService"),
                new LogEntry(now.minusMinutes(2), LivelloLog.ERROR, "Timeout", "AuthService"),
                new LogEntry(now.minusMinutes(1), LivelloLog.ERROR, "NullPointerException", "OrderService"), // Messaggio duplicato
                new LogEntry(now.minusMinutes(15), LivelloLog.INFO, "Service started", "AuthService"),
                new LogEntry(now.minusMinutes(20), LivelloLog.DEBUG, "Initializing beans", "OrderService"),
                new LogEntry(now.minusMinutes(25), LivelloLog.ERROR, "DB Connection lost", "DBService"),
                new LogEntry(now.minusMinutes(30), LivelloLog.ERROR, "Memory leak detected", "PaymentService"),
                new LogEntry(now.minusMinutes(35), LivelloLog.ERROR, "Syntax error in query", "DBService")
        );

        System.out.println("--- TEST ANALISI LOG SERVER ---");

        // 2, 3. Filtrare solo ERROR, ordinare dal più recente, estrarre messaggi unici separati da virgola, max 5 
        String top5ErroriRecenti = logs.stream()
                .filter(log -> log.getLivello() == LivelloLog.ERROR) // Filtro primario
                // Ordinamento cronologico decrescente (i più recenti per primi) usando comparing().reversed() 
                .sorted(Comparator.comparing(LogEntry::getTimestamp).reversed())
                .map(LogEntry::getMessaggio) // Estrazione del solo dato testuale
                .distinct() // Conserva solo i messaggi unici 
                .limit(5) // Tronca il flusso a massimo 5 risultati 
                .collect(Collectors.joining(", ")); // Assemblaggio finale della stringa aggregata

        System.out.println("Top 5 Errori Unici Recenti:\n" + top5ErroriRecenti);

        // 4. Convertire in Map<String, Long> con chiave servizioSorgente e valore conteggio DEBUG 
        Map<String, Long> debugCountPerService = logs.stream()
                .filter(log -> log.getLivello() == LivelloLog.DEBUG)
                // Raggruppa in base al nome del servizio. Collectors.counting() è un downstream per calcolare le frequenze.
                .collect(Collectors.groupingBy(LogEntry::getServizioSorgente, Collectors.counting()));

        System.out.println("\nConteggio log DEBUG per servizio:");
        debugCountPerService.forEach((servizio, conteggio) -> System.out.println(servizio + ": " + conteggio));
    }
}

/* 💡 RIFLESSIONI DEL TUTOR
 * Decision Making: Nella costruzione della pipeline degli errori, l'ordine delle operazioni Stream è essenziale. 
 *                  `sorted` -> `map` -> `distinct` -> `limit`.
 *                  Fare il `distinct` dopo aver mappato i messaggi assicura che identifichiamo l'unicità in base al testo,
 *                  garantendo che venga preservato l'errore cronologicamente più recente (visto che era stato appena ordinato `reversed`).
 * 
 * Alternative: Al posto di `Collectors.counting()`, si poteva utilizzare `Collectors.summingLong(e -> 1L)`, 
 *              che di fatto fa la stessa identica cosa ma in modo meno espressivo.
 * 
 * Pitfalls (Trappole): Spostare `limit(5)` prima di `distinct()` è un potenziale errore gravissimo. Se i primi 5 log
 *                      recenti fossero tutti lo stesso "NullPointerException", un `limit(5)` prematuro causerebbe un output finale con UN SOLO 
 *                      errore anziché 5, poiché `distinct()` rimuoverebbe i 4 duplicati da quel set già ridotto.
 * 
 * Focus: L'uso di `Collectors.joining(", ")` è estremamente potente per risolvere il noioso problema "trailing comma" (la virgola finale appesa) tipico dei loop iterativi classici.
 */