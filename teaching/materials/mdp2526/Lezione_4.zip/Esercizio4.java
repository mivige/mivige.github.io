// Esercizio 4 - Magazzino Generico con Filtri 

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collectors;

// 1. Classe generica Magazzino 
class Magazzino<T> {
    private List<T> articoli = new ArrayList<>();

    public Magazzino(List<T> articoli) {
        this.articoli.addAll(articoli);
    }

    // 2. Metodo che accetta un Predicate e restituisce una lista filtrata 
    // L'utilizzo di Predicate garantisce un disaccoppiamento totale tra contenitore e logica di business.
    public List<T> filtra(Predicate<T> criterio) {
        return articoli.stream()
                .filter(criterio)
                .collect(Collectors.toList());
    }

    // Metodo bonus per facilitare il testing del punto 4
    public Optional<T> trovaPrimo(Predicate<T> criterio) {
        return articoli.stream()
                .filter(criterio)
                .findFirst();
    }
}

class Prodotto {
    private String nome;
    private LocalDate scadenza;

    public Prodotto(String nome, LocalDate scadenza) {
        this.nome = nome;
        this.scadenza = scadenza;
    }

    public String getNome() { return nome; }
    public LocalDate getScadenza() { return scadenza; }

    @Override
    public String toString() { return nome + " (scade: " + scadenza + ")"; }
}

public class Esercizio4 {
    public static void main(String[] args) {
        List<Prodotto> inventario = Arrays.asList(
                new Prodotto("Latte", LocalDate.now().plusDays(2)),
                new Prodotto("Biscotti", LocalDate.now().plusMonths(6)),
                new Prodotto("Yogurt", LocalDate.now().minusDays(1)) // Scaduto
        );

        Magazzino<Prodotto> magazzino = new Magazzino<>(inventario);

        System.out.println("--- TEST MAGAZZINO GENERICO ---");

        // 3. Filtrare i prodotti che scadono prima di una certa data 
        LocalDate dataLimite = LocalDate.now().plusDays(10);
        
        // Passiamo un'espressione lambda che corrisponde alla firma dell'interfaccia funzionale Predicate<T>
        List<Prodotto> prodottiInScadenza = magazzino.filtra(p -> p.getScadenza().isBefore(dataLimite));
        
        System.out.println("Prodotti che scadono prima di " + dataLimite + ":");
        prodottiInScadenza.forEach(System.out::println);

        // 4. Utilizzare findFirst() gestendo l'assenza di risultati 
        Predicate<Prodotto> criterioRicerca = p -> p.getNome().equalsIgnoreCase("Pane"); // Criterio fittizio

        magazzino.trovaPrimo(criterioRicerca)
                .ifPresentOrElse(
                        p -> System.out.println("\nTrovato: " + p),
                        () -> System.out.println("\nNessun prodotto trovato che corrisponde al criterio di ricerca.")
                );
    }
}

/* 💡 RIFLESSIONI DEL TUTOR
 * Decision Making: Ho preferito incapsulare la chiamata `findFirst()` in un metodo delegato all'interno della classe `Magazzino`
 *                  (metodo `trovaPrimo`), piuttosto che restituire l'intera lista ed eseguire la pipeline esternamente, rispettando il principio dell'Information Hiding.
 * 
 * Alternative: Il metodo `filtra` poteva essere scritto senza Stream API (con un ciclo for-each iterativo), 
 *              ma l'uso degli Stream rende l'applicazione dei filtri incredibilmente coincisa.
 * 
 * Pitfalls (Trappole): Un errore comune lavorando con l'oggetto `Optional` ritornato da `findFirst()`  
 *                      è tentare di fare una chiamata diretta al metodo `.get()`. Se la collezione non contiene elementi per quel criterio, verrà sollevata una `NoSuchElementException`. L'utilizzo di `ifPresentOrElse` risolve questo problema elegantemente.
 * 
 * Focus: L'interfaccia funzionale `Predicate<T>` rappresenta una funzione che valuta un argomento e ritorna un boolean. È la base concettuale di ogni meccanismo di filtering e di flessibilità del codice in Java Moderno.
 */