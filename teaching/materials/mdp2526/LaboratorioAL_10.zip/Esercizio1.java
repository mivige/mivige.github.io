/**
 * 1. Processore di Testo Funzionale
 */

import java.util.function.Predicate;

@FunctionalInterface
interface Trasformatore {
    // Unica operazione abstract: definisce il contratto per la lambda
    String trasforma(String x);
}

class EditorDiTesto {

    // Metodo di ordine superiore: accetta un comportamento (Trasformatore) come parametro
    public static String elabora(String s, Trasformatore t) {
        return t.trasforma(s);
    }

    // Estensione con Predicate per validazione logica prima della trasformazione
    public static String elaboraSeValido(String s, Trasformatore t, Predicate<String> p) {
        // test() valuta la condizione booleana definita nella lambda Predicate
        if (p.test(s)) {
            return t.trasforma(s);
        }
        return s; // Restituisce l'originale se la condizione non è soddisfatta
    }
}

public class Esercizio1 {
    public static void main(String[] args) {
        String input = "Programmazione";

        // 1. Conversione in maiuscolo
        String maiuscolo = EditorDiTesto.elabora(input, s -> s.toUpperCase());
        System.out.println("Maiuscolo: " + maiuscolo);

        // 2. Aggiunta prefisso LOG:
        String log = EditorDiTesto.elabora(input, s -> "LOG: " + s);
        System.out.println("Log: " + log);

        // 3. Inversione stringa usando StringBuilder (efficienza O(n))
        String invertita = EditorDiTesto.elabora(input, s -> new StringBuilder(s).reverse().toString());
        System.out.println("Invertita: " + invertita);

        // 4. Test elaboraSeValido (lunghezza minima 5)
        String valida = EditorDiTesto.elaboraSeValido(input, 
            s -> s.toLowerCase(), 
            s -> s.length() > 5 // Predicate: ritorna true se lunghezza > 5
        );
        System.out.println("Valida (min 5): " + valida);

        String nonValida = EditorDiTesto.elaboraSeValido("Java", 
            s -> s.toLowerCase(), 
            s -> s.length() > 5
        );
        System.out.println("Non Valida (rimane uguale): " + nonValida);
    }
}

/*
💡 RIFLESSIONI DEL TUTOR

Decision Making: Ho scelto di definire l'interfaccia personalizzata Trasformatore come richiesto, 
anche se Java fornisce già Function<String, String>. Questo serve a far capire come nascono le 
interfacce funzionali "sotto il cofano".

Alternative: In elaboraSeValido avremmo potuto lanciare un'eccezione in caso di validazione fallita, 
ma restituire la stringa originale è un approccio più "fluido" e meno prono a interruzioni di flusso.

Pitfalls (Trappole): Gli studenti spesso dimenticano che le lambda possono accedere a variabili 
esterne solo se sono final o "effectively final". Provare a modificare 'input' dentro la lambda causerebbe un errore.

Focus: L'uso di @FunctionalInterface non è obbligatorio per il compilatore (basta un solo metodo abstract), 
ma è una best practice fondamentale per prevenire l'aggiunta accidentale di altri metodi in futuro.
*/