/**
 * 5. Il Percorso ad Ostacoli
 */

import java.util.Random;

class Robot {
    private int posizione = 0;
    private int energia = 100;
    private boolean effettoFango = false;

    public void muovi(int passi, int lunghezzaPercorso) {
        // Se c'è fango, i passi sono dimezzati
        int passiEffettivi = effettoFango ? passi / 2 : passi;
        effettoFango = false; // L'effetto dura un solo turno
        
        // Movimento circolare tramite operatore modulo %
        posizione = (posizione + passiEffettivi) % lunghezzaPercorso;
        energia -= 5; // Il movimento consuma energia base
    }

    public void setFango(boolean attivo) { this.effettoFango = attivo; }
    public void modificaEnergia(int delta) { this.energia += delta; }
    public void setPosizione(int pos) { this.posizione = pos; }
    public int getPosizione() { return posizione; }
    public int getEnergia() { return energia; }
}

interface Casella {
    void calpesta(Robot r, Percorso p);
}

class CasellaPiana implements Casella {
    public void calpesta(Robot r, Percorso p) { /* Nulla accade */ }
}

class CasellaRicarica implements Casella {
    private int k;
    public CasellaRicarica(int k) { this.k = k; }
    public void calpesta(Robot r, Percorso p) { r.modificaEnergia(k); }
}

class CasellaFango implements Casella {
    public void calpesta(Robot r, Percorso p) { r.setFango(true); }
}

class CasellaTeletrasporto implements Casella {
    private Random rnd = new Random();
    public void calpesta(Robot r, Percorso p) {
        r.setPosizione(rnd.nextInt(p.getLunghezza()));
    }
}

class Percorso {
    private Casella[] caselle;

    public Percorso(int n) {
        caselle = new Casella[n];
        Random rnd = new Random();
        for (int i = 0; i < n; i++) {
            int tipo = rnd.nextInt(4);
            caselle[i] = switch(tipo) {
                case 1 -> new CasellaRicarica(20);
                case 2 -> new CasellaFango();
                case 3 -> new CasellaTeletrasporto();
                default -> new CasellaPiana();
            };
        }
    }

    public int getLunghezza() { return caselle.length; }
    public Casella getCasella(int pos) { return caselle[pos]; }
}

class Simulazione {
    public static void esegui() {
        Robot bot = new Robot();
        Percorso pista = new Percorso(20);
        Random rnd = new Random();

        for (int turno = 1; turno <= 10; turno++) {
            int lancioDadi = rnd.nextInt(6) + 1;
            bot.muovi(lancioDadi, pista.getLunghezza());
            
            // Applica effetto della casella di arrivo
            pista.getCasella(bot.getPosizione()).calpesta(bot, pista);

            System.out.printf("Turno %d: Posizione %d | Energia %d\n", 
                turno, bot.getPosizione(), bot.getEnergia());
            
            if (bot.getEnergia() <= 0) {
                System.out.println("Robot esaurito!");
                break;
            }
        }
    }
}

public class Esercizio5 {
    public static void main(String[] args) {
        Simulazione.esegui();
    }
}

/*
💡 RIFLESSIONI DEL TUTOR

Decision Making: Il movimento circolare `(pos + passi) % lunghezza` è la tecnica più pulita 
per gestire percorsi che ricominciano, evitando complessi cicli if/else.

Alternative: Potevamo implementare le Caselle come classe astratta invece di interfaccia, 
ma dato che non condividono alcuno stato, l'interfaccia è più leggera.

Pitfalls (Trappole): Gestire il teletrasporto richiede che la casella conosca la lunghezza 
totale del percorso. Per questo ho passato l'oggetto Percorso `p` come parametro al metodo `calpesta`.

Focus: Questo esercizio dimostra il Polimorfismo in azione: il ciclo di simulazione non sa 
cosa farà la casella, si limita a invocare `calpesta()`, e ogni sottotipo reagisce a modo suo.
*/