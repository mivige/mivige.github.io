/**
 * 4. Simulatore di Officina Meccanica
 */

import java.util.Random;
import java.util.ArrayList;
import java.util.List;

abstract class Componente {
    private String nome;
    private double costo;

    public Componente(String nome, double costo) {
        this.nome = nome;
        this.costo = costo;
    }

    public String getNome() { return nome; }
    public double getCosto() { return costo; }
}

class Pneumatico extends Componente { public Pneumatico() { super("Pneumatico", 80.0); } }
class FiltroOlio extends Componente { public FiltroOlio() { super("Filtro Olio", 25.0); } }
class PastigliaFreno extends Componente { public PastigliaFreno() { super("Pastiglia Freno", 45.0); } }

class Officina {
    private Componente[] magazzino;
    private List<Componente> contoCorrente = new ArrayList<>();
    private Random rnd = new Random();

    public Officina(int m) {
        this.magazzino = new Componente[m];
    }

    public void rifornisci() {
        for (int i = 0; i < magazzino.length; i++) {
            int scelta = rnd.nextInt(3);
            // Switch moderno (Java 14+) per inizializzare il magazzino
            magazzino[i] = switch (scelta) {
                case 0 -> new Pneumatico();
                case 1 -> new FiltroOlio();
                default -> new PastigliaFreno();
            };
        }
    }

    public Componente applicaComponente(int indice) {
        if (indice < 0 || indice >= magazzino.length || magazzino[indice] == null) {
            System.err.println("Componente non disponibile all'indice " + indice);
            return null;
        }
        Componente scelto = magazzino[indice];
        magazzino[indice] = null; // Rimozione logica dall'array
        contoCorrente.add(scelto);
        return scelto;
    }

    public double getTotale() {
        // Stream API per sommare i costi in modo funzionale
        return contoCorrente.stream().mapToDouble(Componente::getCosto).sum();
    }

    public void emettiFattura() {
        System.out.println("------- FATTURA CLIENTE -------");
        for (Componente c : contoCorrente) {
            System.out.println("- " + c.getNome() + ": €" + c.getCosto());
        }
        System.out.println("TOTALE: €" + getTotale());
        contoCorrente.clear(); // Azzeramento per il prossimo cliente
        System.out.println("------------------------------\n");
    }
}

public class Esercizio4 {
    public static void main(String[] args) {
        Officina officina = new Officina(10);
        officina.rifornisci();

        officina.applicaComponente(0);
        officina.applicaComponente(2);
        officina.applicaComponente(5);

        officina.emettiFattura();
        
        // Test tentativo di riuso componente già rimosso
        officina.applicaComponente(0); 
    }
}

/*
💡 RIFLESSIONI DEL TUTOR

Decision Making: Ho usato un array fisso per il magazzino (come richiesto) ma una List 
per il conto corrente. Questo perché il magazzino ha una capacità nota (M), mentre il numero 
di componenti applicati a un cliente è variabile.

Alternative: Il magazzino poteva essere una Map<TipoComponente, Integer> per gestire le 
quantità, ma l'esercizio chiedeva esplicitamente la gestione tramite indice.

Pitfalls (Trappole): La gestione dei null negli array. Dopo aver rimosso un componente, 
bisogna sempre controllare che `magazzino[i] != null` prima di accedervi per evitare NullPointerException.

Focus: L'uso di una classe base astratta Componente impedisce l'istanziazione di un "componente generico", 
forzando l'uso di parti specifiche del veicolo.
*/