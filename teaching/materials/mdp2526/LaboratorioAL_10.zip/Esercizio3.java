/**
 * 3. Sistema di Gestione Attuatori
 */

import java.util.ArrayList;
import java.util.List;

class DispositivoDomo {
    private final String nome;
    private boolean acceso;
    // Lista polimorfica per mantenere traccia delle azioni eseguite
    private final List<Azione> storico = new ArrayList<>();

    public DispositivoDomo(String nome) {
        this.nome = nome;
        this.acceso = false;
    }

    public void setStato(boolean stato) { this.acceso = stato; }
    public boolean isAcceso() { return acceso; }
    public String getNome() { return nome; }

    public void riceviAzione(Azione a) {
        a.esegui(this); // Polimorfismo: il comportamento dipende dal tipo dinamico di 'a'
        storico.add(a);
    }

    public void mostraStorico() {
        System.out.println("Storico per " + nome + ":");
        for (Azione a : storico) {
            // getClass().getSimpleName() estrae il nome della classe dell'istanza
            System.out.println("- " + a.getClass().getSimpleName());
        }
    }
}

interface Azione {
    void esegui(DispositivoDomo d);
}

class Accensione implements Azione {
    public void esegui(DispositivoDomo d) { d.setStato(true); }
}

class Spegnimento implements Azione {
    public void esegui(DispositivoDomo d) { d.setStato(false); }
}

class InvertiStato implements Azione {
    public void esegui(DispositivoDomo d) { d.setStato(!d.isAcceso()); }
}

class LogStato implements Azione {
    public void esegui(DispositivoDomo d) {
        System.out.println("[LOG] " + d.getNome() + " è " + (d.isAcceso() ? "ACCESO" : "SPENTO"));
    }
}

public class Esercizio3 {
    public static void main(String[] args) {
        DispositivoDomo lampada = new DispositivoDomo("Lampada Salotto");

        lampada.riceviAzione(new Accensione());
        lampada.riceviAzione(new LogStato());
        lampada.riceviAzione(new InvertiStato());
        lampada.riceviAzione(new LogStato());
        lampada.riceviAzione(new Spegnimento());

        System.out.println();
        lampada.mostraStorico();
    }
}

/*
💡 RIFLESSIONI DEL TUTOR

Decision Making: Ho scelto una List (ArrayList) per lo storico perché garantisce l'ordine 
di inserimento, che è il requisito fondamentale per una timeline di eventi.

Alternative: Le azioni potevano essere implementate come Enum se fossero state fisse, ma 
usare un'interfaccia permette di aggiungere nuovi tipi di azioni (es. Dimmerazione) senza 
mai toccare le classi esistenti (Open/Closed Principle).

Pitfalls (Trappole): Spesso gli studenti mettono la logica di cambio stato dentro il Dispositivo. 
Qui invece il Dispositivo è passivo, e l'Azione è l'oggetto "intelligente" (Command Pattern semplificato).

Focus: Il disaccoppiamento tra chi invoca l'azione e chi la esegue rende il sistema scalabile e modulare.
*/