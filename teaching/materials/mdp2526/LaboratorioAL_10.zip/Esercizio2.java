/**
 * 2. Cronometro Digitale & Cronometro con Millisecondi
 */

class Cronometro {
    protected int secondi; // protected per permettere l'accesso alla sottoclasse
    protected final int maxSecondi;

    public Cronometro(int maxSecondi) {
        this.maxSecondi = maxSecondi;
        this.secondi = 0;
    }

    public void tic() {
        if (secondi < maxSecondi) {
            secondi++;
        }
    }

    @Override
    public String toString() {
        // %02d formatta l'intero con due cifre, aggiungendo lo zero iniziale se necessario
        return String.format("[%02d/%d]", secondi, maxSecondi);
    }
}

class CronometroPreciso extends Cronometro {
    private int millisecondi;

    public CronometroPreciso(int maxSecondi) {
        super(maxSecondi);
        this.millisecondi = 0;
    }

    @Override
    public void tic() {
        // Incremento di 100ms per ogni chiamata
        millisecondi += 100;
        
        // Gestione dell'overflow: se raggiungiamo 1000ms, incrementiamo i secondi della superclasse
        if (millisecondi >= 1000) {
            super.tic(); // Riutilizziamo la logica di incremento e controllo massimi del padre
            millisecondi = 0;
        }
    }

    @Override
    public String toString() {
        // Richiama il toString del padre e concatena la precisione aggiuntiva
        return super.toString() + ": " + millisecondi + "ms";
    }
}

public class Esercizio2 {
    public static void main(String[] args) {
        System.out.println("--- Test Cronometro Standard ---");
        Cronometro c1 = new Cronometro(3);
        c1.tic();
        c1.tic();
        System.out.println(c1); // [02/3]

        System.out.println("\n--- Test Cronometro Preciso ---");
        CronometroPreciso cp = new CronometroPreciso(60);
        for (int i = 0; i < 12; i++) {
            cp.tic(); // Chiamiamo 12 volte -> 1.2 secondi
        }
        System.out.println(cp); // [01/60]: 200ms
        
        // Test caso limite: superamento secondi
        CronometroPreciso limite = new CronometroPreciso(1);
        for (int i = 0; i < 15; i++) limite.tic();
        System.out.println("Limite 1sec superato: " + limite);
    }
}

/*
💡 RIFLESSIONI DEL TUTOR

Decision Making: Ho usato il modificatore 'protected' per 'secondi' e 'maxSecondi' per facilitare 
l'estendibilità, evitando di dover creare getter/setter solo per la sottoclasse.

Alternative: Potevamo usare l'API java.time (Duration) per gestire il tempo, ma l'esercizio 
mira a testare la logica manuale di incremento e l'overriding.

Pitfalls (Trappole): Un errore comune è dimenticare di chiamare super.tic() o super.toString(), 
finendo per riscrivere da zero una logica che è già presente nella classe base (violando il principio DRY).

Focus: L'overriding del metodo toString() è fondamentale in Java per fornire una rappresentazione 
leggibile degli oggetti durante il debug o la stampa a video.
*/