// ESERCIZIO 3: Pipeline di Elaborazione Prezzi

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

class CalcolatoreFiscale {
    // Lista di funzioni che prendono un Double e restituiscono un Double //
    private final List<Function<Double, Double>> pipeline;

    public CalcolatoreFiscale(List<Function<Double, Double>> pipeline) {
        this.pipeline = new ArrayList<>(pipeline);
    }

    /**
     * Applica tutte le trasformazioni in sequenza al valore iniziale.
     */
    public Double applicaTasse(Double valore) {
        Double risultato = valore;
        for (Function<Double, Double> step : pipeline) {
            // Applica la funzione corrente al risultato parziale precedente //
            risultato = step.apply(risultato);
        }
        return risultato;
    }
}

public class Esercizio3 {
    public static void main(String[] args) {
        // Definizione della pipeline con Lambda e Method References //
        List<Function<Double, Double>> operazioni = List.of(
            prezzo -> prezzo * 0.9,       // 1. Sconto 10%
            Math::ceil,                   // 2. Arrotondamento superiore
            prezzo -> prezzo + 5.50,      // 3. Quota fissa
            prezzo -> prezzo * 1.22       // 4. IVA 22%
        );

        CalcolatoreFiscale calcolatore = new CalcolatoreFiscale(operazioni);

        Double prezzoIniziale = 100.0;
        Double prezzoFinale = calcolatore.applicaTasse(prezzoIniziale);

        // Calcolo manuale per verifica: 
        // 100 * 0.9 = 90.0
        // ceil(90.0) = 90.0
        // 90.0 + 5.50 = 95.5
        // 95.5 * 1.22 = 116.51
        System.out.println("Prezzo Iniziale: " + prezzoIniziale);
        System.out.println("Prezzo Finale (dopo pipeline): " + prezzoFinale);
    }
}

/*
 💡 RIFLESSIONI DEL TUTOR
 
 Decision Making:
 Ho scelto una List<Function> per permettere l'estendibilità dinamica. 
 La pipeline può essere modificata a runtime aggiungendo nuovi step senza cambiare la classe Calcolatore.
 
 Alternative:
 Invece di un ciclo for nel metodo applicaTasse, avremmo potuto concatenare le funzioni 
 usando andThen(): pipeline.stream().reduce(Function.identity(), Function::andThen).apply(valore).
 
 Pitfalls:
 L'uso di tipi wrapper (Double invece di double) può causare NullPointerException se non si 
 controlla che l'input o i risultati delle funzioni siano null. In una pipeline finanziaria 
 è sempre bene gestire la precisione decimale (magari con BigDecimal in produzione).
 
 Focus:
 Function<T, R> è un'interfaccia funzionale standard: T è il tipo di input, R il tipo di output. 
 Qui sono entrambi Double.
*/