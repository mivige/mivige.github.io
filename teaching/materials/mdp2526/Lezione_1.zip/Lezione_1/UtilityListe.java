// ESERCIZIO 1: Inverti lista e massimo

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.NoSuchElementException;

public class UtilityListe {

    /**
     * Inverte una lista creando una nuova istanza.
     * @param lista La lista originale (non viene modificata)
     * @param <T> Tipo generico degli elementi
     * @return Una nuova lista con ordine invertito
     */
    public static <T> List<T> inverti(List<T> lista) {
        if (lista == null) return null;
        // Creiamo una nuova ArrayList basata sulla vecchia per non alterare l'input //
        List<T> copia = new ArrayList<>(lista);
        // Utilizziamo l'utility di Collections per l'inversione in-place sulla copia //
        Collections.reverse(copia);
        return copia;
    }

    /**
     * Trova il massimo in una lista di elementi comparabili.
     * @param lista Lista di elementi
     * @param <T> Tipo che deve implementare l'interfaccia Comparable
     * @return L'elemento massimo
     * @throws NoSuchElementException se la lista è vuota
     */
    // <T extends Comparable<T>> garantisce che T possa essere confrontato con oggetti del suo stesso tipo //
    public static <T extends Comparable<T>> T max(List<T> lista) {
        if (lista == null || lista.isEmpty()) {
            throw new NoSuchElementException("La lista è vuota o nulla.");
        }

        T massimo = lista.get(0);
        for (T elemento : lista) {
            // compareTo restituisce > 0 se l'oggetto corrente è maggiore dell'argomento //
            if (elemento.compareTo(massimo) > 0) {
                massimo = elemento;
            }
        }
        return massimo;
    }

    public static void main(String[] args) {
        List<Integer> numeri = List.of(10, 5, 20, 15, 30);
        List<String> parole = List.of("Alfa", "Zeta", "Beta", "Gamma");

        // Test Inverti
        System.out.println("Originale: " + numeri + " -> Invertita: " + inverti(numeri));
        
        // Test Max
        System.out.println("Massimo numeri: " + max(numeri)); // 30
        System.out.println("Massimo parole: " + max(parole)); // Zeta

        // Caso limite: Lista vuota per max
        try {
            max(new ArrayList<Integer>());
        } catch (NoSuchElementException e) {
            System.out.println("Eccezione gestita correttamente per lista vuota");
        }
    }
}

/*
 💡 RIFLESSIONI DEL TUTOR
 
 Decision Making:
 Ho scelto di restituire una "nuova" lista nel metodo inverti() per rispettare il principio di immutabilità 
 dei dati in ingresso, evitando effetti collaterali (side-effects) sulla lista originale.
 
 Alternative:
 In inverti(), invece di Collections.reverse(), si poteva usare un ciclo for inverso aggiungendo 
 elementi a una nuova lista, ma le API standard di Java sono più efficienti e leggibili.
 Per max(), in Java 8+ si poteva usare: lista.stream().max(Comparator.naturalOrder()).
 
 Pitfalls:
 L'errore più comune è non gestire il caso di lista vuota, che causerebbe un IndexOutOfBoundsException 
 chiamando lista.get(0). Un altro errore è tentare di usare operatori come '>' su tipi generici; 
 i generici richiedono obbligatoriamente compareTo().
 
 Focus:
 Il vincolo <T extends Comparable<T>> è fondamentale: senza di esso, il compilatore non saprebbe che 
 l'oggetto di tipo T possiede il metodo compareTo.
*/