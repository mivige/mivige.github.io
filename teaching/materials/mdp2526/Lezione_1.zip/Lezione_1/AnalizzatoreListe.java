// ESERCIZIO 4: Analisi Generica di Liste

import java.util.*;

public class AnalizzatoreListe {

    /**
     * Filtra gli elementi compresi tra min e max (inclusi).
     */
    // T deve estendere Comparable per permettere l'uso di compareTo //
    public static <T extends Comparable<T>> List<T> filtraCompresi(List<T> lista, T min, T max) {
        List<T> risultato = new ArrayList<>();
        for (T elemento : lista) {
            // compareTo >= 0 significa "maggiore o uguale" //
            // compareTo <= 0 significa "minore o uguale" //
            if (elemento.compareTo(min) >= 0 && elemento.compareTo(max) <= 0) {
                risultato.add(elemento);
            }
        }
        return risultato;
    }

    /**
     * Trova l'elemento che compare con la frequenza massima.
     */
    public static <T> T trovaElementoDominante(List<T> lista) {
        if (lista == null || lista.isEmpty()) return null;

        // Mappa per contare le occorrenze: Chiave = Elemento, Valore = Conteggio //
        Map<T, Integer> frequenze = new HashMap<>();
        
        for (T elemento : lista) {
            // merge incrementa il valore esistente o imposta 1 se assente //
            frequenze.merge(elemento, 1, Integer::sum);
        }

        T dominante = null;
        int maxFrequenza = -1;

        for (Map.Entry<T, Integer> entry : frequenze.entrySet()) {
            if (entry.getValue() > maxFrequenza) {
                maxFrequenza = entry.getValue();
                dominante = entry.getKey();
            }
        }

        return dominante;
    }

    public static void main(String[] args) {
        List<Integer> voti = List.of(18, 24, 30, 24, 28, 24, 18, 30, 30, 30);

        // Test filtraCompresi (voti tra 25 e 30)
        System.out.println("Voti alti (25-30): " + filtraCompresi(voti, 25, 30));

        // Test elemento dominante
        System.out.println("Voto più frequente (Dominante): " + trovaElementoDominante(voti));
        
        List<String> nomi = List.of("Marco", "Anna", "Marco", "Luca", "Anna", "Marco");
        System.out.println("Nome dominante: " + trovaElementoDominante(nomi));
    }
}

/*
 💡 RIFLESSIONI DEL TUTOR
 
 Decision Making:
 Per filtraCompresi ho usato un'ArrayList perché non conosciamo a priori la dimensione 
 del risultato e l'accesso sequenziale è efficiente. 
 Per trovaElementoDominante, HashMap è la scelta ideale per conteggi veloci (O(n) totale).
 
 Alternative:
 filtraCompresi può essere scritto in una riga con gli Stream:
 return lista.stream().filter(x -> x.compareTo(min) >= 0 && x.compareTo(max) <= 0).toList();
 
 Pitfalls:
 In filtraCompresi, se l'utente passa min > max, la lista restituita sarà sempre vuota. 
 In trovaElementoDominante, se ci sono due elementi con la stessa frequenza massima, 
 il codice restituisce il primo trovato; bisognerebbe specificare nei requisiti come gestire i pareggi.
 
 Focus:
 Nota che filtraCompresi richiede <T extends Comparable<T>>, mentre trovaElementoDominante no. 
 Questo perché per contare le frequenze serve solo equals() (gestito internamente da HashMap), 
 non un ordinamento naturale.
*/