// ESERCIZIO 2: Sistema di Monitoraggio Sensori

import java.util.*;

class Sensore implements Comparable<Sensore> {
    private final String codiceSeriale;
    private final String tipologia;
    private final String zona;

    public Sensore(String codiceSeriale, String tipologia, String zona) {
        this.codiceSeriale = codiceSeriale;
        this.tipologia = tipologia;
        this.zona = zona;
    }

    public String getCodiceSeriale() { return codiceSeriale; }
    public String getTipologia() { return tipologia; }
    public String getZona() { return zona; }

    // Uguaglianza basata esclusivamente sul codice seriale //
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Sensore sensore)) return false; // Pattern Matching for instanceof (Java 16+) //
        return Objects.equals(codiceSeriale, sensore.codiceSeriale);
    }

    @Override
    public int hashCode() {
        return Objects.hash(codiceSeriale);
    }

    // Ordinamento per zona e poi per tipologia (richiesto per ReteOrdinata/TreeSet) //
    @Override
    public int compareTo(Sensore altro) {
        int compZona = this.zona.compareTo(altro.zona);
        if (compZona != 0) return compZona;
        return this.tipologia.compareTo(altro.tipologia);
    }

    @Override
    public String toString() {
        return String.format("[%s] %s in %s", codiceSeriale, tipologia, zona);
    }
}

class ReteSensori {
    protected Set<Sensore> sensori;

    public ReteSensori() {
        // HashSet garantisce l'unicità basandosi su equals/hashCode //
        this.sensori = new HashSet<>();
    }

    public boolean aggiungiSensore(Sensore s) {
        return sensori.add(s);
    }

    public void stampa() {
        sensori.forEach(System.out::println);
    }
}

class ReteOrdinata extends ReteSensori {
    public ReteOrdinata() {
        // TreeSet ordina gli elementi basandosi sul metodo compareTo della classe Sensore //
        this.sensori = new TreeSet<>();
    }
}

public class Esercizio2 {
    public static void main(String[] args) {
        Sensore s1 = new Sensore("SN001", "Temperatura", "Zona A");
        Sensore s2 = new Sensore("SN001", "Umidità", "Zona B"); // Duplicato seriale
        Sensore s3 = new Sensore("SN002", "Pressione", "Zona B");
        Sensore s4 = new Sensore("SN003", "Temperatura", "Zona B");

        System.out.println("--- Test HashSet (Unicità) ---");
        ReteSensori reteBase = new ReteSensori();
        reteBase.aggiungiSensore(s1);
        boolean aggiunto = reteBase.aggiungiSensore(s2); // Dovrebbe essere false
        System.out.println("S2 aggiunto? " + aggiunto);
        reteBase.stampa();

        System.out.println("\n--- Test TreeSet (Ordinamento) ---");
        ReteOrdinata reteOrd = new ReteOrdinata();
        reteOrd.aggiungiSensore(s1);
        reteOrd.aggiungiSensore(s3);
        reteOrd.aggiungiSensore(s4);
        reteOrd.stampa(); // Ordine: Zona A, poi Zona B (Pressione), poi Zona B (Temperatura)
    }
}

/*
 💡 RIFLESSIONI DEL TUTOR
 
 Decision Making:
 Ho usato HashSet per la versione base perché garantisce O(1) per l'inserimento e la ricerca. 
 Per ReteOrdinata, TreeSet è obbligatorio per mantenere l'ordine logico (O(log n)).
 
 Alternative:
 Invece di implementare Comparable dentro Sensore, avremmo potuto passare un Comparator 
 esterno al costruttore del TreeSet: new TreeSet<>(Comparator.comparing(Sensore::getZona).thenComparing(Sensore::getTipologia)).
 
 Pitfalls:
 Uno degli errori più critici è la discrepanza tra equals() e compareTo(). 
 Se s1.equals(s2) è true, allora s1.compareTo(s2) dovrebbe restituire 0. 
 Qui c'è una trappola: se definiamo l'uguaglianza solo sul seriale ma l'ordinamento su zona/tipo, 
 il TreeSet potrebbe considerare "diversi" due sensori con lo stesso seriale se hanno zone diverse. 
 In un contesto reale, l'identità (equals) e l'ordine (compareTo) dovrebbero essere coerenti.
 
 Focus:
 Il Pattern Matching per instanceof (usato nell'equals) rende il codice più pulito evitando il cast manuale.
*/